package com.company;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class KassaThreadOKU extends Thread{
    Socket socket;
    Connection connection;
    ObjectInputStream ois;

    public KassaThreadOKU(Socket socket, Connection connection) throws IOException {
        this.socket = socket;
        this.connection = connection;
        ois = new ObjectInputStream(socket.getInputStream());
    }


    @Override
    public void run() {
            while (true){
                try{
                    Object object = ois.readObject();
                    if(object instanceof String){
                        if(object.equals("flights")){
                            ObjectOutputStream ous = new ObjectOutputStream(socket.getOutputStream());
                            ous.writeObject(FlightData());
                        }if(object.equals("aircrafts")){
                            ObjectOutputStream ous = new ObjectOutputStream(socket.getOutputStream());
                            ous.writeObject(AircraftData());
                        }if(object.equals("cities")){
                            ObjectOutputStream ous = new ObjectOutputStream(socket.getOutputStream());
                            ous.writeObject(CityData());
                        }if(object.equals("tickets")){
                            ObjectOutputStream ous = new ObjectOutputStream(socket.getOutputStream());
                            ous.writeObject(TicketData());
                        }
                    }if(object instanceof TicketPackage){
                        TicketPackage tp = (TicketPackage) object;
                        if(tp.operationType.equals("add")){
                            AddTicket(tp.ticket);
                        }if(tp.operationType.equals("delete")){
                            DeleteTicket(tp.ticket);
                        }
                    }if(object instanceof AircraftPackage){
                        AircraftPackage ap = (AircraftPackage)object;
                        if(ap.operationType.equals("add")){
                            AddAircraft(ap.airCraft);
                        }if(ap.operationType.equals("delete")){
                            DeleteAircraft(ap.airCraft);
                        }
                    }if(object instanceof TicketEditPackage){
                        TicketEditPackage tep = (TicketEditPackage)object;
                        if(tep.parameter.equals("flight_id")){
                            DeleteTicket(tep.ticket);
                            Ticket ticket = new Ticket(tep.ticket.id,tep.integer,tep.ticket.name,tep.ticket.surname,tep.ticket.passport_number,tep.ticket.ticket_type);
                            AddTicket(ticket);
                        }if(tep.parameter.equals("id")){
                            DeleteTicket(tep.ticket);
                            Ticket ticket = new Ticket(tep.integer,tep.ticket.flight_id,tep.ticket.name,tep.ticket.surname,tep.ticket.passport_number,tep.ticket.ticket_type);
                            AddTicket(ticket);
                        }if(tep.parameter.equals("name")){
                            DeleteTicket(tep.ticket);
                            Ticket ticket = new Ticket(tep.ticket.id,tep.ticket.flight_id,tep.string,tep.ticket.surname,tep.ticket.passport_number,tep.ticket.ticket_type);
                            AddTicket(ticket);
                        }if(tep.parameter.equals("surname")){
                            DeleteTicket(tep.ticket);
                            Ticket ticket = new Ticket(tep.ticket.id,tep.ticket.flight_id,tep.ticket.name,tep.string,tep.ticket.passport_number,tep.ticket.ticket_type);
                            AddTicket(ticket);
                        }if(tep.parameter.equals("passport_number")){
                            DeleteTicket(tep.ticket);
                            Ticket ticket = new Ticket(tep.ticket.id,tep.ticket.flight_id,tep.ticket.name,tep.ticket.surname,tep.string,tep.ticket.ticket_type);
                            AddTicket(ticket);
                        }if(tep.parameter.equals("ticket_type")){
                            DeleteTicket(tep.ticket);
                            Ticket ticket = new Ticket(tep.ticket.id,tep.ticket.flight_id,tep.ticket.name,tep.ticket.surname,tep.ticket.passport_number,tep.string);
                            AddTicket(ticket);
                        }
                    }
                }catch(Exception e){
                }
            }
    }
    public ArrayList<Flight> FlightData(){
        ArrayList<Flight> flights = new ArrayList<>();
        try {
            PreparedStatement st = connection.prepareStatement("SELECT * FROM flights");
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                int aircraft_id = rs.getInt("aircraft_id");
                int departure_city_id = rs.getInt("departure_city_id");
                int arrival_city_id = rs.getInt("arrival_city_id");
                int departure_time = rs.getInt("departure_time");
                int econom_place_capacity = rs.getInt("econom_place_price");
                int business_place_price = rs.getInt("business_place_price");
                flights.add(new Flight(id, aircraft_id, departure_city_id, arrival_city_id,departure_time,econom_place_capacity,business_place_price));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flights;
    }
    public void AddTicket(Ticket ticket) {
        try {
            PreparedStatement st = connection.prepareStatement("INSERT INTO tickets(id,flight_id,name,surname,passport_number,ticket_type)VALUES(?,?,?,?,?,?)");
            st.setInt(1, ticket.id);
            st.setInt(2, ticket.flight_id);
            st.setString(3, ticket.name);
            st.setString(4, ticket.surname);
            st.setString(5, ticket.passport_number);
            st.setString(6, ticket.ticket_type);
            st.execute();
            st.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void DeleteTicket(Ticket ticket){
        try {
            PreparedStatement st = connection.prepareStatement("DELETE FROM tickets where id = ?");
            st.setInt(1,ticket.id);
            st.execute();
            st.close();
        } catch (Exception throwables) {
            throwables.printStackTrace();
        }
    }public ArrayList<AirCraft> AircraftData() {
        ArrayList<AirCraft> aircrafts = new ArrayList<>();
        try {
            PreparedStatement st = connection.prepareStatement("SELECT * FROM aircrafts");
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String model = rs.getString("model");
                int business_class_capacity = rs.getInt("business_class_capacity");
                int econom_class_capacity = rs.getInt("econom_class_capacity");
                aircrafts.add(new AirCraft(id, name, model, business_class_capacity, econom_class_capacity));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return aircrafts;
    }
    public ArrayList<City> CityData() {
        ArrayList<City> cities = new ArrayList<>();
        try {
            PreparedStatement st = connection.prepareStatement("SELECT * FROM cities");
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String country = rs.getString("country");
                String short_name = rs.getString("short_name");
                cities.add(new City(id, name, country, short_name));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cities;
    }
    public ArrayList<Ticket> TicketData() {
        ArrayList<Ticket> tickets = new ArrayList<>();
        try {
            PreparedStatement st = connection.prepareStatement("SELECT * FROM tickets");
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                int flight_id = rs.getInt("flight_id");
                String name = rs.getString("name");
                String surname = rs.getString("surname");
                String passport_number = rs.getString("passport_number");
                String ticket_type = rs.getString("ticket_type");
                tickets.add(new Ticket(id,flight_id, name, surname, passport_number,ticket_type));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return tickets;
    }
    public void AddAircraft(AirCraft aircraft) {
        try {
            PreparedStatement st = connection.prepareStatement("INSERT INTO aircrafts(id,name,model,business_class_capacity,econom_class_capacity)VALUES(?,?,?,?,?)");
            st.setInt(1, aircraft.id);
            st.setString(2, aircraft.name);
            st.setString(3, aircraft.model);
            st.setInt(4, aircraft.business_class_capacity);
            st.setInt(5, aircraft.econom_class_capacity);
            st.execute();
            st.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void DeleteAircraft(AirCraft airCraft) {
        try {
            PreparedStatement st = connection.prepareStatement("DELETE FROM aircrafts where name = ?");
            st.setString(1, airCraft.name);
            st.execute();
            st.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
