package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EditCityInt extends JPanel {
    AdminFrame adminFrame;
    JLabel enterl;
    JTextField enter;
    JButton back;
    JButton edit;
    public EditCityInt(AdminFrame adminFrame){
        this.adminFrame = adminFrame;
        setSize(520,500);
        setLayout(null);
        Color blue = new Color(18, 77, 114);
        Color grey = new Color(102, 102, 102);
        setBackground(grey);
        enterl = new JLabel("ENTER INT:");
        enterl.setBounds(100,100,300,30);
        enterl.setForeground(Color.white);
        add(enterl);
        enter = new JTextField();
        enter.setBounds(100,150,300,30);
        add(enter);
        back = new JButton("BACK");
        back.setBounds(275,400,100,30);
        back.setBackground(blue);
        back.setForeground(Color.white);
        add(back);
        edit = new JButton("EDIT");
        edit.setBounds(125,400,100,30);
        edit.setBackground(blue);
        edit.setForeground(Color.white);
        add(edit);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adminFrame.getEditCityInt().setVisible(false);
                adminFrame.getEditCityParameter().setVisible(true);
            }
        });
        edit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(adminFrame.getEditCityParameter().parameter.getText().equals("id")){
                    int id = 0;
                    City city = null;
                    for(int i =0; i<adminFrame.sendListC("cities").size();i++){
                        if(adminFrame.sendListC("cities").get(i).id == Integer.parseInt(adminFrame.getEditCityParameter().id.getText())){
                            System.out.println("id found");
                            id = Integer.parseInt(enter.getText());
                            city = adminFrame.sendListC("cities").get(i);
                        }
                    }
                    adminFrame.CityEditInt("id",city,id);
                    enter.setText("");
                    adminFrame.getEditAircraftParameter().parameter.setText("");
                    adminFrame.getEditAircraftParameter().id.setText("");
                }
            }
        });
    }
}
