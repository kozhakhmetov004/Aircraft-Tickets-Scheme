package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class TicketMenu extends JPanel {
    KassaFrame kassaFrame;
    JButton add;
    JButton edit;
    JButton delete;
    JButton back;
    String [] listen;
    ArrayList<String> impostorss = new ArrayList<>();
    public TicketMenu(KassaFrame kassaFrame){
        this.kassaFrame = kassaFrame;
        setSize(520,500);
        setLayout(null);
        setBackground(kassaFrame.getKassaMainmenu().red);
        add = new JButton("ADD");
        add.setBounds(150,50,200,50);
        add.setBackground(Color.white);
        add.setForeground(kassaFrame.getKassaMainmenu().red);
        add(add);
        edit = new JButton("EDIT");
        edit.setBounds(150,150,200,50);
        edit.setBackground(Color.white);
        edit.setForeground(kassaFrame.getKassaMainmenu().red);
        add(edit);
        delete = new JButton("DELETE");
        delete.setBounds(150,250,200,50);
        delete.setBackground(Color.white);
        delete.setForeground(kassaFrame.getKassaMainmenu().red);
        add(delete);
        back = new JButton("BACK");
        back.setBounds(150,350,200,50);
        back.setBackground(Color.white);
        back.setForeground(kassaFrame.getKassaMainmenu().red);
        add(back);
        delete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                kassaFrame.getTicketMenu().setVisible(false);
                kassaFrame.getDeleteTicket().setVisible(true);
            }
        });
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                kassaFrame.getTicketMenu().setVisible(false);
                kassaFrame.getKassaMainmenu().setVisible(true);
            }
        });
        edit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                kassaFrame.getEditTicketParameter().setVisible(true);
                kassaFrame.getTicketMenu().setVisible(false);
            }
        });
        add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                kassaFrame.getTicketMenu().setVisible(false);
                kassaFrame.getAddTicket().setVisible(true);
                listen = new String[kassaFrame.sendListF("flights").size()];
                for(int i =0;i <kassaFrame.sendListF("flights").size();i++){
                    listen[i] = String.valueOf(kassaFrame.sendListF("flights").get(i).id);
                }


                if(listen.length<kassaFrame.getAddTicket().flight_id.getItemCount()) {
                    ArrayList<String> impostors = new ArrayList<>();

                    for(int i = 0;i<kassaFrame.getAddTicket().flight_id.getItemCount();i++){
                        int dursemes =0;
                        for(int j =0; j<listen.length;j++){
                            if(Integer.parseInt((String) kassaFrame.getAddTicket().flight_id.getItemAt(i))!=Integer.parseInt(listen[j])){

                                dursemes++;
                            }
                        }
                        if(dursemes==listen.length){
                            impostors.add((String) kassaFrame.getAddTicket().flight_id.getItemAt(i));
                        }


                    }
                        for (int i = 0; i < (kassaFrame.getAddTicket().flight_id.getItemCount() - listen.length); i++) {
                            kassaFrame.getAddTicket().flight_id.removeItem(impostors.get(i));
                        }
                    }
                if(listen.length>kassaFrame.getAddTicket().flight_id.getItemCount()) {

                    for(int i =0;i<(listen.length-kassaFrame.getAddTicket().flight_id.getItemCount());i++){
                        impostorss.add(listen[listen.length-1-i]);
                    }
                    for(int i =0;i<(listen.length-kassaFrame.getAddTicket().flight_id.getItemCount());i++){
                        kassaFrame.getAddTicket().flight_id.addItem(impostorss.get(i));
                    }
                }



            }
        });
    }
}
