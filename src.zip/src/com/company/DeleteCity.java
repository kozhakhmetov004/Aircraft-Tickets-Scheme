package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DeleteCity extends JPanel {
    AdminFrame main;
    JLabel idl;
    JTextField id;
    JButton delete;
    JButton back;
    public DeleteCity(AdminFrame main){
        this.main = main;
        setSize(520,500);
        setLayout(null);
        Color blue = new Color(18, 77, 114);
        Color grey = new Color(102, 102, 102);
        setBackground(grey);
        idl = new JLabel("ID:");
        idl.setBounds(100,200,300,30);
        add(idl);
        idl.setForeground(Color.white);
        id= new JTextField();
        id.setBounds(100,235,300,30);
        add(id);
        delete = new JButton("DELETE");
        delete.setBounds(125,400,100,30);
        delete.setBackground(blue);
        add(delete);
        back = new JButton("BACK");
        back.setBounds(275,400,100,30);
        back.setBackground(blue);
        add(back);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                main.getDeletePanel().setVisible(true);
                main.getDeleteCity().setVisible(false);
            }
        });
        delete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                City city = new City(Integer.parseInt(id.getText()),null,null,null);
                main.DeleteCity(city);
                id.setText("");
            }
        });
    }
}
