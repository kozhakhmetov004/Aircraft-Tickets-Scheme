package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EditTicketString extends JPanel {
    KassaFrame kassaFrame;
    JLabel enterl;
    JTextField enter;
    JButton back;
    JButton edit;
    JComboBox ticket_Type;
    String[] ticket_types = new String[2];
    public EditTicketString(KassaFrame kassaFrame){
        ticket_types[0]="ec";
        ticket_types[1]="bc";
        this.kassaFrame = kassaFrame;
        setSize(520,500);
        setLayout(null);
        setBackground(kassaFrame.getKassaMainmenu().red);
        enterl = new JLabel("ENTER STRING:");
        enterl.setBounds(100,100,300,30);
        enterl.setForeground(Color.white);
        add(enterl);
        enter = new JTextField();
        enter.setBounds(100,150,300,30);
        enter.setForeground(kassaFrame.getKassaMainmenu().red);
        enter.setBackground(Color.white);
        add(enter);
        ticket_Type = new JComboBox(ticket_types);
        ticket_Type.setBounds(100,150,300,30);
        ticket_Type.setBackground(Color.white);
        ticket_Type.setForeground(kassaFrame.getKassaMainmenu().red);
        add(ticket_Type);
        ticket_Type.setVisible(false);
        back = new JButton("BACK");
        back.setBounds(275,400,100,30);
        back.setBackground(Color.white);
        back.setForeground(kassaFrame.getKassaMainmenu().red);
        add(back);
        edit = new JButton("EDIT");
        edit.setBounds(125,400,100,30);
        edit.setBackground(Color.white);
        edit.setForeground(kassaFrame.getKassaMainmenu().red);
        add(edit);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                kassaFrame.getEditTicketParameter().setVisible(true);
                kassaFrame.getEditTicketString().setVisible(false);
            }
        });
        edit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(kassaFrame.getEditTicketParameter().parameter.getText().equals("name")){
                    String name  = "";
                    Ticket ticket = null;
                    for(int i =0; i<kassaFrame.sendListT("tickets").size();i++){
                        if(kassaFrame.sendListT("tickets").get(i).id == Integer.parseInt(kassaFrame.getEditTicketParameter().id.getText())){
                            name = enter.getText();
                            ticket = kassaFrame.sendListT("tickets").get(i);
                        }
                    }
                    kassaFrame.TicketEditString("name",ticket,name);
                    enter.setText("");
                    kassaFrame.getEditTicketParameter().parameter.setText("");
                    kassaFrame.getEditTicketParameter().id.setText("");
                }if(kassaFrame.getEditTicketParameter().parameter.getText().equals("surname")){
                    String surname  = "";
                    Ticket ticket = null;
                    for(int i =0; i<kassaFrame.sendListT("tickets").size();i++){
                        if(kassaFrame.sendListT("tickets").get(i).id == Integer.parseInt(kassaFrame.getEditTicketParameter().id.getText())){
                            surname = enter.getText();
                            ticket = kassaFrame.sendListT("tickets").get(i);
                        }
                    }
                    kassaFrame.TicketEditString("surname",ticket,surname);
                    enter.setText("");
                    kassaFrame.getEditTicketParameter().parameter.setText("");
                    kassaFrame.getEditTicketParameter().id.setText("");
                }if(kassaFrame.getEditTicketParameter().parameter.getText().equals("passport_number")){
                    String passport_number  = "";
                    Ticket ticket = null;
                    for(int i =0; i<kassaFrame.sendListT("tickets").size();i++){
                        if(kassaFrame.sendListT("tickets").get(i).id == Integer.parseInt(kassaFrame.getEditTicketParameter().id.getText())){
                            passport_number = enter.getText();
                            ticket = kassaFrame.sendListT("tickets").get(i);
                        }
                    }
                    kassaFrame.TicketEditString("passport_number",ticket,passport_number);
                    enter.setText("");
                    kassaFrame.getEditTicketParameter().parameter.setText("");
                    kassaFrame.getEditTicketParameter().id.setText("");
                }if(kassaFrame.getEditTicketParameter().parameter.getText().equals("ticket_type")){
                    String ticket_type  = "";
                    Ticket ticket = null;
                    for(int i =0; i<kassaFrame.sendListT("tickets").size();i++){
                        if(kassaFrame.sendListT("tickets").get(i).id == Integer.parseInt(kassaFrame.getEditTicketParameter().id.getText())){
                            ticket_type = (String) ticket_Type.getSelectedItem();
                            ticket = kassaFrame.sendListT("tickets").get(i);
                        }
                    }
                    kassaFrame.TicketEditString("ticket_type",ticket,ticket_type);
                    ticket_Type.setSelectedIndex(0);
                    kassaFrame.getEditTicketParameter().parameter.setText("");
                    kassaFrame.getEditTicketParameter().id.setText("");
                }
            }
        });
    }
}
