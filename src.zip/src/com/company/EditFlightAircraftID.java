package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EditFlightAircraftID extends JPanel {
    AdminFrame adminFrame;
    JButton edit;
    JButton back;
    JLabel enterl;
    JComboBox enter;
    String[] aircrafts_ids;
    public EditFlightAircraftID(AdminFrame adminFrame){
        this.adminFrame = adminFrame;
        setSize(520,500);
        setLayout(null);
        setBackground(adminFrame.grey);
        enterl = new JLabel("CHOOSE AIRCRAFT ID:");
        enterl.setBounds(100, 100, 300, 30);
        enterl.setForeground(Color.white);
        add(enterl);
        back = new JButton("BACK");
        back.setBounds(275, 400, 100, 30);
        back.setBackground(adminFrame.blue);
        back.setForeground(Color.white);
        add(back);
        edit = new JButton("EDIT");
        edit.setBounds(125, 400, 100, 30);
        edit.setBackground(adminFrame.blue);
        edit.setForeground(Color.white);
        add(edit);
        aircrafts_ids = new String[adminFrame.sendList("aircrafts").size()];
        for(int i =0;i<adminFrame.sendList("aircrafts").size();i++){
            aircrafts_ids[i]= String.valueOf(adminFrame.sendList("aircrafts").get(i).id);
        }
        enter = new JComboBox(aircrafts_ids);
        enter.setBounds(100,150,300,30);
        add(enter);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adminFrame.getEditFlightAircraftID().setVisible(false);
                adminFrame.getEditFlightParameter().setVisible(true);
            }
        });
        edit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(adminFrame.getEditFlightParameter().parameter.getText().equals("aircraft_id")){
                    int aircraft_id = 0;
                    Flight flight = null;
                    for(int i =0; i<adminFrame.sendListF("flights").size();i++){
                        if(adminFrame.sendListF("flights").get(i).id == Integer.parseInt(adminFrame.getEditFlightParameter().id.getText())){
                            aircraft_id = Integer.parseInt((String) enter.getSelectedItem());
                            flight = adminFrame.sendListF("flights").get(i);
                        }
                    }
                    adminFrame.FlightEditInt("aircraft_id",flight,aircraft_id);
                    enter.setSelectedIndex(0);
                    adminFrame.getEditFlightParameter().parameter.setText("");
                    adminFrame.getEditFlightParameter().id.setText("");
                }
            }
        });
    }
}
