package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Mainmenu extends JPanel {
    AdminFrame adminFrame;
    JButton add;
    JButton delete;
    JButton exit;
    JButton edit;
    public Mainmenu(AdminFrame adminFrame){
        this.adminFrame = adminFrame;
        setSize(520,500);
        setLayout(null);
        Color blue = new Color(18, 77, 114);
        Color grey = new Color(102, 102, 102);
        setBackground(grey);
        add = new JButton("ADD");
        add.setBounds(150,50,200,50);
        add.setBackground(blue);
        add.setForeground(Color.white);
        add(add);
        edit = new JButton("EDIT");
        edit.setBounds(150,150,200,50);
        edit.setBackground(blue);
        edit.setForeground(Color.white);
        add(edit);
        delete = new JButton("DELETE");
        delete.setBounds(150,250,200,50);
        delete.setBackground(blue);
        delete.setForeground(Color.white);
        add(delete);
        exit = new JButton("EXIT");
        exit.setBounds(150,350,200,50);
        exit.setBackground(blue);
        exit.setForeground(Color.white);
        add(exit);
        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adminFrame.getMainmenu().setVisible(false);
                adminFrame.getAddpanel().setVisible(true);
            }
        });
        delete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adminFrame.getDeletePanel().setVisible(true);
                adminFrame.getMainmenu().setVisible(false);
            }
        });
        edit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adminFrame.getMainmenu().setVisible(false);
                adminFrame.getEditPanel().setVisible(true);
            }
        });

    }
}
