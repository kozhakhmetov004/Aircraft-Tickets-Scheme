package com.company;

import java.net.ServerSocket;
import java.sql.Connection;
import java.sql.DriverManager;

public class Main {
    static Connection connection;
    public static void main(String[] args) {
        try {
            ServerSocket kassir = new ServerSocket(2022);
            ServerSocket admin = new ServerSocket(2020);
            connect();
            KassirSrThread kst = new KassirSrThread(kassir,connection);
            AdminSrThread ast = new AdminSrThread(admin,connection);
            kst.start();
            ast.start();
        } catch (Exception e) {
        }
    }
    public static void connect(){
        try{ Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/air?useUnicode=true&serverTimezone=UTC", "root", "");
        }catch(Exception e){
            e.printStackTrace();
        }
    }


}
