package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EditAircraftString extends JPanel {
    AdminFrame adminFrame;
    JLabel enterl;
    JTextField enter;
    JButton back;
    JButton edit;
    public EditAircraftString(AdminFrame adminFrame){
        this.adminFrame = adminFrame;
        setSize(520,500);
        setLayout(null);
        Color blue = new Color(18, 77, 114);
        Color grey = new Color(102, 102, 102);
        setBackground(grey);
        enterl = new JLabel("ENTER STRING:");
        enterl.setBounds(100,100,300,30);
        enterl.setForeground(Color.white);
        add(enterl);
        enter = new JTextField();
        enter.setBounds(100,150,300,30);
        add(enter);
        back = new JButton("BACK");
        back.setBounds(275,400,100,30);
        back.setBackground(blue);
        back.setForeground(Color.white);
        add(back);
        edit = new JButton("EDIT");
        edit.setBounds(125,400,100,30);
        edit.setBackground(blue);
        edit.setForeground(Color.white);
        add(edit);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adminFrame.getEditAircraftParameter().setVisible(true);
                adminFrame.getEditAircraftString().setVisible(false);
            }
        });
        edit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(adminFrame.getEditAircraftParameter().parameter.getText().equals("name")){
                    String name = "";
                    AirCraft airCraft = null;
                    for(int i =0; i<adminFrame.sendList("aircrafts").size();i++){
                        if(adminFrame.sendList("aircrafts").get(i).id == Integer.parseInt(adminFrame.getEditAircraftParameter().id.getText())){
                            name = (enter.getText());
                            airCraft = adminFrame.sendList("aircrafts").get(i);
                        }
                    }
                    adminFrame.AircraftEditString("name",airCraft,name);
                    enter.setText("");
                    adminFrame.getEditAircraftParameter().parameter.setText("");
                    adminFrame.getEditAircraftParameter().id.setText("");
                }
                if(adminFrame.getEditAircraftParameter().parameter.getText().equals("model")){
                    String model = "";
                    AirCraft airCraft = null;
                    for(int i =0; i<adminFrame.sendList("aircrafts").size();i++){
                        if(adminFrame.sendList("aircrafts").get(i).id == Integer.parseInt(adminFrame.getEditAircraftParameter().id.getText())){
                            model = (enter.getText());
                            airCraft = adminFrame.sendList("aircrafts").get(i);
                        }
                    }
                    adminFrame.AircraftEditString("model",airCraft,model);
                    enter.setText("");
                    adminFrame.getEditAircraftParameter().parameter.setText("");
                    adminFrame.getEditAircraftParameter().id.setText("");
                }
            }
        });
    }
}
