package com.company;

import java.net.Socket;
public class Kassir {
    public static  void main(String []args){
        try {
            Socket socket1 = new Socket("127.0.0.1", 2022);
            System.out.println("WAITING FOR SERVER");
            KassaFrame kassaFrame = new KassaFrame(socket1);
            kassaFrame.setVisible(true);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
