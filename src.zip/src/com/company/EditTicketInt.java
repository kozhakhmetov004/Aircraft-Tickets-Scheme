package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EditTicketInt extends JPanel {
    KassaFrame kassaFrame;
    JLabel enterl;
    JTextField enter;
    JButton back;
    JButton edit;
    JLabel error;
    public EditTicketInt(KassaFrame kassaFrame) {
        this.kassaFrame = kassaFrame;
        setSize(520, 500);
        setLayout(null);
        setBackground(kassaFrame.getKassaMainmenu().red);
        enterl = new JLabel("ENTER INT:");
        enterl.setBounds(100, 100, 300, 30);
        enterl.setForeground(Color.white);
        add(enterl);
        enter = new JTextField();
        enter.setBounds(100, 150, 300, 30);
        enter.setBackground(Color.white);
        enter.setForeground(kassaFrame.getKassaMainmenu().red);
        add(enter);
        back = new JButton("BACK");
        back.setBounds(275, 400, 100, 30);
        back.setBackground(Color.white);
        back.setForeground(kassaFrame.getKassaMainmenu().red);
        add(back);
        edit = new JButton("EDIT");
        edit.setBounds(125, 400, 100, 30);
        edit.setBackground(Color.white);
        edit.setForeground(kassaFrame.getKassaMainmenu().red);
        add(edit);
        error = new JLabel("YOU SHOULD ENTER INTEGER");
        error.setBounds(100,300,300,50);
        error.setForeground(Color.white);
        add(error);
        error.setVisible(false);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                kassaFrame.getEditTicketInt().setVisible(false);
                kassaFrame.getEditTicketParameter().setVisible(true);
            }
        });
        edit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                    try{
                        if (kassaFrame.getEditTicketParameter().parameter.getText().equals("id")) {
                            int id = 0;
                            Ticket ticket = null;
                            for (int i = 0; i < kassaFrame.sendListT("tickets").size(); i++) {
                                if (kassaFrame.sendListT("tickets").get(i).id == Integer.parseInt(kassaFrame.getEditTicketParameter().id.getText())) {
                                    id = Integer.parseInt(enter.getText());
                                    ticket = kassaFrame.sendListT("tickets").get(i);
                                }
                            }
                            kassaFrame.TicketEditInt("id", ticket, id);
                            enter.setText("");
                            kassaFrame.getEditTicketParameter().parameter.setText("");
                            kassaFrame.getEditTicketParameter().id.setText("");
                        }
                    }catch(NumberFormatException er){
                        error.setVisible(true);
                    }



            }
        });

    }

}
