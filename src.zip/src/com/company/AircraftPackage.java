package com.company;

import java.io.Serializable;

public class AircraftPackage implements Serializable {
    String operationType;
    AirCraft airCraft;
    public AircraftPackage(String operationType, AirCraft airCraft) {
        this.operationType = operationType;
        this.airCraft = airCraft;
    }
}
