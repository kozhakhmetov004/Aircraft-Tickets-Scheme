package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SearchTicket extends JPanel {
    KassaFrame kassaFrame;
    JButton next;
    JButton back;
    JComboBox available_tickets;
    JLabel available_ticketsl;
    public SearchTicket(KassaFrame kassaFrame){
        this.kassaFrame = kassaFrame;
        setSize(520,500);
        setLayout(null);
        setBackground(kassaFrame.getKassaMainmenu().red);
        back = new JButton("BACK");
        back.setBackground(Color.white);
        back.setForeground(kassaFrame.getKassaMainmenu().red);
        back.setBounds(150,400,200,50);
        add(back);
        available_tickets = new JComboBox();
        available_tickets.setSelectedItem(null);
        available_tickets.setForeground(kassaFrame.getKassaMainmenu().red);
        available_tickets.setBackground(Color.white);
        available_tickets.setBounds(100,100,300,30);
        add(available_tickets);
        available_ticketsl = new JLabel("TICKETS MATCHING YOUR SETTINGS:");
        available_ticketsl.setForeground(Color.white);
        available_ticketsl.setBounds(100,50,300,30);
        add(available_ticketsl);
        next = new JButton("NEXT STEP");
        next.setBounds(100,300,300,50);
        next.setForeground(kassaFrame.getKassaMainmenu().red);
        next.setBackground(Color.white);
        add(next);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                kassaFrame.getBuyTicket().setVisible(true);
                kassaFrame.getSearchTicket().setVisible(false);
                available_tickets.removeAllItems();
            }
        });
        next.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {


                for(int i =0; i<kassaFrame.sendListT("tickets").size();i++){
                    if((kassaFrame.sendListT("tickets").get(i).flight_id)==((Integer) kassaFrame.getSearchTicket().available_tickets.getSelectedItem())){
                        kassaFrame.getBuySelectedTicket().selected_ticket = kassaFrame.sendListT("tickets").get(i);
                    }
                }
                for(int i =0; i<kassaFrame.sendListF("flights").size();i++){
                    if(kassaFrame.sendListF("flights").get(i).id == kassaFrame.getBuySelectedTicket().selected_ticket.flight_id){
                        kassaFrame.getBuySelectedTicket().selected_flight = kassaFrame.sendListF("flights").get(i);
                    }
                }
                for(int i=0;i<kassaFrame.sendList("aircrafts").size();i++){
                    if (kassaFrame.sendList("aircrafts").get(i).id ==kassaFrame.getBuySelectedTicket().selected_flight.aircraft_id){
                        kassaFrame.getBuySelectedTicket().selected_aircraft = kassaFrame.sendList("aircrafts").get(i);
                    }
                }
                if(kassaFrame.getBuySelectedTicket().selected_ticket.ticket_type.equals("bc")){
                    kassaFrame.getBuySelectedTicket().Cost.setText("COST FOR THIS TICKET IS "+kassaFrame.getBuySelectedTicket().selected_flight.bysiness_class_price+" Tg");
                }if(kassaFrame.getBuySelectedTicket().selected_ticket.ticket_type.equals("ec")){
                    kassaFrame.getBuySelectedTicket().Cost.setText("COST FOR THIS TICKET IS "+kassaFrame.getBuySelectedTicket().selected_flight.econom_class_price+" Tg");
                }
                kassaFrame.getSearchTicket().setVisible(false);
                kassaFrame.getBuySelectedTicket().setVisible(true);
                kassaFrame.getBuySelectedTicket().setSize(520,500);
            }
        });
        }
}
