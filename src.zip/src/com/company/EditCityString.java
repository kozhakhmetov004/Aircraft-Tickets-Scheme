package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EditCityString extends JPanel {
    AdminFrame adminFrame;
    JLabel enterl;
    JTextField enter;
    JButton back;
    JButton edit;
    public EditCityString(AdminFrame adminFrame){
        this.adminFrame = adminFrame;
        setSize(520,500);
        setLayout(null);
        Color blue = new Color(18, 77, 114);
        Color grey = new Color(102, 102, 102);
        setBackground(grey);
        enterl = new JLabel("ENTER STRING:");
        enterl.setBounds(100,100,300,30);
        enterl.setForeground(Color.white);
        add(enterl);
        enter = new JTextField();
        enter.setBounds(100,150,300,30);
        add(enter);
        back = new JButton("BACK");
        back.setBounds(275,400,100,30);
        back.setBackground(blue);
        back.setForeground(Color.white);
        add(back);
        edit = new JButton("EDIT");
        edit.setBounds(125,400,100,30);
        edit.setBackground(blue);
        edit.setForeground(Color.white);
        add(edit);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adminFrame.getEditCityParameter().setVisible(true);
                adminFrame.getEditCityString().setVisible(false);
            }
        });
        edit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(adminFrame.getEditCityParameter().parameter.getText().equals("name")){
                    String name  = "";
                    City city = null;
                    for(int i =0; i<adminFrame.sendListC("cities").size();i++){
                        if(adminFrame.sendListC("cities").get(i).id == Integer.parseInt(adminFrame.getEditCityParameter().id.getText())){
                            name = enter.getText();
                            city = adminFrame.sendListC("cities").get(i);
                        }
                    }
                    adminFrame.CityEditString("name",city,name);
                    enter.setText("");
                    adminFrame.getEditAircraftParameter().parameter.setText("");
                    adminFrame.getEditAircraftParameter().id.setText("");
                }if(adminFrame.getEditCityParameter().parameter.getText().equals("country")){
                    String country  = "";
                    City city = null;
                    for(int i =0; i<adminFrame.sendListC("cities").size();i++){
                        if(adminFrame.sendListC("cities").get(i).id == Integer.parseInt(adminFrame.getEditCityParameter().id.getText())){
                            country = enter.getText();
                            city = adminFrame.sendListC("cities").get(i);
                        }
                    }
                    adminFrame.CityEditString("country",city,country);
                    enter.setText("");
                    adminFrame.getEditAircraftParameter().parameter.setText("");
                    adminFrame.getEditAircraftParameter().id.setText("");
                }if(adminFrame.getEditCityParameter().parameter.getText().equals("short_name")){
                    String short_name  = "";
                    City city = null;
                    for(int i =0; i<adminFrame.sendListC("cities").size();i++){
                        if(adminFrame.sendListC("cities").get(i).id == Integer.parseInt(adminFrame.getEditCityParameter().id.getText())){
                            short_name = enter.getText();
                            city = adminFrame.sendListC("cities").get(i);
                        }
                    }
                    adminFrame.CityEditString("short_name",city,short_name);
                    enter.setText("");
                    adminFrame.getEditAircraftParameter().parameter.setText("");
                    adminFrame.getEditAircraftParameter().id.setText("");
                }
            }
        });
    }
}
