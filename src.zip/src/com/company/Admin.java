package com.company;

import java.net.Socket;

public class Admin {
    public static void main(String []args){
        try {
            Socket socket1 = new Socket("127.0.0.1",2020);
            System.out.println("WAITING FOR SERVER");
            AdminFrame adminFrame = new AdminFrame(socket1);
            adminFrame.setVisible(true);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
