package com.company;

import java.io.Serializable;

public class CityPackage implements Serializable {
    String operationType;
    City city;

    public CityPackage(String operationType, City city) {
        this.operationType = operationType;
        this.city = city;
    }
}
