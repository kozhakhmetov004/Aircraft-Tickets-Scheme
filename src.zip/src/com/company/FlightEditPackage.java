package com.company;

import java.io.Serializable;

public class FlightEditPackage implements Serializable {
    String parameter;
    Flight flight;
    int integer;

    public FlightEditPackage(String parameter, Flight flight, int integer) {
        this.parameter = parameter;
        this.flight = flight;
        this.integer = integer;
    }
}
