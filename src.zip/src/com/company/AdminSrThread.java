package com.company;

import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;

public class AdminSrThread extends Thread{
    ServerSocket socket;
    Connection connection;
    public AdminSrThread(ServerSocket socket, Connection connection) {
        this.socket = socket;
        this.connection = connection;
    }
    @Override
    public void run() {
        while(socket.isBound()) {
            try {
                Socket socket2 = socket.accept();
                System.out.println("ADMIN CONNECTED");
                AdminThreadOKU ato = new AdminThreadOKU(socket2, connection);
                ato.start();
                System.out.println("ADMIN IS WORKING");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
