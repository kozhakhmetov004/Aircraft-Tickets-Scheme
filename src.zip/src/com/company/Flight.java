package com.company;

import java.io.Serializable;

public class Flight implements Serializable {
    int id;
    int aircraft_id;
    int departurecityid;
    int arrivalcityid;
    int time;
    int econom_class_price;
    int bysiness_class_price;

    public Flight(int id, int aircraft, int departurecity, int arrivalcity, int time, int econom_class_price, int bysiness_class_price) {
        this.id = id;
        this.aircraft_id = aircraft;
        this.departurecityid = departurecity;
        this.arrivalcityid = arrivalcity;
        this.time = time;
        this.econom_class_price = econom_class_price;
        this.bysiness_class_price = bysiness_class_price;
    }

}
