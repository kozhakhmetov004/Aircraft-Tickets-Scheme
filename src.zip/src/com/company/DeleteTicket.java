package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DeleteTicket extends JPanel {
    KassaFrame kassaFrame;
    JLabel idl;
    JTextField id;
    JButton delete;
    JButton back;
    public DeleteTicket(KassaFrame kassaFrame){
        this.kassaFrame = kassaFrame;
        Color red = kassaFrame.getKassaMainmenu().red;
        setSize(520,500);
        setLayout(null);
        setBackground(red);
        idl = new JLabel("ID:");
        idl.setBounds(100,200,300,30);
        add(idl);
        idl.setForeground(Color.white);
        id= new JTextField();
        id.setBounds(100,235,300,30);
        id.setBackground(Color.white);
        id.setForeground(red);
        add(id);
        delete = new JButton("DELETE");
        delete.setBounds(125,400,100,30);
        delete.setBackground(Color.white);
        add(delete);
        back = new JButton("BACK");
        back.setBounds(275,400,100,30);
        back.setBackground(Color.white);
        back.setForeground(red);
        add(back);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                kassaFrame.getDeleteTicket().setVisible(false);
                kassaFrame.getTicketMenu().setVisible(true);
            }
        });
        delete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Ticket ticket = new Ticket(Integer.parseInt(id.getText()),0,null,null,null,null);
                kassaFrame.deleteTicket(ticket);
                id.setText("");
            }
        });
    }
}
