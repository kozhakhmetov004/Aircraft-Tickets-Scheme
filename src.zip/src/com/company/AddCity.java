package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddCity extends JPanel {
    AdminFrame main;
    JTextField id;
    JTextField name;
    JTextField country;
    JTextField short_name;
    JLabel idl;
    JLabel namel;
    JLabel countryl;
    JLabel short_namel;
    JButton add;
    JButton back;
    public AddCity(AdminFrame main){
        this.main = main;
        setSize(520,500);
        setLayout(null);
        Color blue = new Color(18, 77, 114);
        Color grey = new Color(102, 102, 102);
        setBackground(grey);
        add = new JButton("ADD");
        add.setBounds(125,400,100,30);
        add.setBackground(blue);
        add(add);
        back = new JButton("BACK");
        back.setBounds(275,400,100,30);
        back.setBackground(blue);
        add(back);
        idl = new JLabel("ID:");
        idl.setBounds(100,10,200,30);
        add(idl);
        idl.setForeground(Color.white);
        id = new JTextField();
        id.setBounds(100,45,300,30);
        add(id);
        namel = new JLabel("NAME:");
        namel.setBounds(100,85,200,30);
        namel.setForeground(Color.white);
        add(namel);
        name = new JTextField();
        name.setBounds(100,120,300,30);
        add(name);
        countryl = new JLabel("COUNTRY:");
        countryl.setBounds(100,160,200,30);
        countryl.setForeground(Color.white);
        add(countryl);
        country = new JTextField();
        country.setBounds(100,195,300,30);
        add(country);
        short_namel = new JLabel("SHORT NAME:");
        short_namel.setBounds(100,235,200,30);
        short_namel.setForeground(Color.white);
        add(short_namel);
        short_name = new JTextField();
        short_name.setBounds(100,270,300,30);
        add(short_name);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                main.getAddCity().setVisible(false);
                main.getAddpanel().setVisible(true);
            }
        });
        add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    City city = new City(Integer.parseInt(id.getText()),name.getText(),(country.getText()),(short_name.getText()));
                    main.sendCity(city);
                    id.setText("");
                    name.setText("");
                    country.setText("");
                    short_name.setText("");
                } catch (Exception s) {
                    s.printStackTrace();
                }
            }
        });
    }
}
