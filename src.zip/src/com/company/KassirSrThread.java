package com.company;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;

public class KassirSrThread extends Thread{
    ServerSocket socket;
    Connection connection;

    public KassirSrThread(ServerSocket socket, Connection connection) {
        this.socket = socket;
        this.connection = connection;
    }

    @Override
    public void run() {
        while(socket.isBound()) {
            try {
                Socket sockets = socket.accept();
                System.out.println("KASSIR CONNECTED");
                KassaThreadOKU kto = new KassaThreadOKU(sockets,connection);
                kto.start();
                System.out.println("KASSIR IS WORKING");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
