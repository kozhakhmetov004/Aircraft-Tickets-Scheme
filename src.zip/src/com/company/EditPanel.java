package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EditPanel extends JPanel {
    AdminFrame adminFrame;
    JButton aircrafts;
    JButton cities;
    JButton flights;
    JButton back;
    public EditPanel(AdminFrame adminFrame){
        this.adminFrame = adminFrame;
        setSize(520,500);
        setLayout(null);
        Color blue = new Color(18, 77, 114);
        Color grey = new Color(102, 102, 102);
        setBackground(grey);
        aircrafts = new JButton("Aircraft");
        aircrafts.setBounds(50,150,100,50);
        aircrafts.setBackground(blue);
        add(aircrafts);
        cities = new JButton("City");
        cities.setBounds(200,150,100,50);
        cities.setBackground(blue);
        add(cities);
        flights = new JButton("Flight");
        flights.setBounds(350,150,100,50);
        flights.setBackground(blue);
        add(flights);
        back = new JButton("BACK");
        back.setBounds(150,300,200,50);
        back.setBackground(blue);
        add(back);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adminFrame.getMainmenu().setVisible(true);
                adminFrame.getEditPanel().setVisible(false);
            }
        });
        aircrafts.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adminFrame.getEditPanel().setVisible(false);
                adminFrame.getEditAircraftParameter().setVisible(true);

            }
        });
        cities.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adminFrame.getEditPanel().setVisible(false);
                adminFrame.getEditCityParameter().setVisible(true);
            }
        });
        flights.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adminFrame.getEditPanel().setVisible(false);
                adminFrame.getEditFlightParameter().setVisible(true);
            }
        });
    }
}
