package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EditTicketFlightID extends JPanel {
    KassaFrame kassaFrame;
    JButton edit;
    JButton back;
    JLabel enterl;
    JComboBox enter;
    String[] flight_ids;
    public EditTicketFlightID(KassaFrame kassaFrame) {
        this.kassaFrame = kassaFrame;
        setSize(520, 500);
        setLayout(null);
        setBackground(kassaFrame.getKassaMainmenu().red);
        enterl = new JLabel("CHOOSE FLIGHT ID:");
        enterl.setBounds(100, 100, 300, 30);
        enterl.setForeground(Color.white);
        add(enterl);
        back = new JButton("BACK");
        back.setBounds(275, 400, 100, 30);
        back.setBackground(Color.white);
        back.setForeground(kassaFrame.getKassaMainmenu().red);
        add(back);
        edit = new JButton("EDIT");
        edit.setBounds(125, 400, 100, 30);
        edit.setBackground(Color.white);
        edit.setForeground(kassaFrame.getKassaMainmenu().red);
        add(edit);
        flight_ids = new String[kassaFrame.sendListF("flights").size()];
        for (int i = 0; i < kassaFrame.sendListF("flights").size(); i++) {
            flight_ids[i] = String.valueOf(kassaFrame.sendListF("flights").get(i).id);
        }
        enter = new JComboBox(flight_ids);
        enter.setBounds(100, 150, 300, 30);
        add(enter);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                kassaFrame.getEditTicketFlightID().setVisible(false);
                kassaFrame.getEditTicketParameter().setVisible(true);
            }
        });
        edit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (kassaFrame.getEditTicketParameter().parameter.getText().equals("flight_id")) {
                    int flight_id = 0;
                    Ticket ticket = null;
                    for (int i = 0; i < kassaFrame.sendListT("tickets").size(); i++) {
                        if (kassaFrame.sendListT("tickets").get(i).id == Integer.parseInt(kassaFrame.getEditTicketParameter().id.getText())) {
                            flight_id = Integer.parseInt((String) enter.getSelectedItem());
                            ticket = kassaFrame.sendListT("tickets").get(i);
                        }
                    }
                    kassaFrame.TicketEditInt("flight_id", ticket, flight_id);
                    enter.setSelectedIndex(0);
                    kassaFrame.getEditTicketParameter().parameter.setText("");
                    kassaFrame.getEditTicketParameter().id.setText("");
                }
            }
        });
    }
}
