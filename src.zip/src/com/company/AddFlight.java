package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddFlight extends JPanel{
    AdminFrame main;
    JLabel idl;
    JComboBox aircraft_idcb	;
    JLabel departure_city_idl	;
    JLabel arrival_city_idl	;
    JLabel departure_timel	;
    JLabel econom_place_pricel	;
    JLabel business_place_pricel;
    JButton add;
    JButton back;
    JTextField id;
    JLabel aircraft_id	;
    JComboBox departure_city_idcb	;
    JComboBox arrival_city_idcb	;
    JTextField departure_time	;
    JTextField econom_place_price	;
    JTextField business_place_price;
    public AddFlight(AdminFrame main){
        this.main = main;
        setSize(520,500);
        setLayout(null);
        Color blue = new Color(18, 77, 114);
        Color grey = new Color(102, 102, 102);
        setBackground(grey);
        String[] idss = new String[ main.sendList("aircrafts").size()];
        for(int i =0;i<main.sendList("aircrafts").size();i++){
            idss[i] = String.valueOf((main.sendList("aircrafts").get(i).name));
        }
        String[] idsss = new String[ main.sendListC("cities").size()];
        for(int i =0;i<main.sendListC("cities").size();i++){
            idsss[i] = String.valueOf((main.sendListC("cities").get(i).name));
        }
        aircraft_idcb = new JComboBox(idss);
        aircraft_idcb.setBounds(10,120,200,30);
        add(aircraft_idcb);
        add = new JButton("ADD");
        add.setBounds(125,400,100,30);
        add.setBackground(blue);
        add(add);
        back = new JButton("BACK");
        back.setBounds(275,400,100,30);
        back.setBackground(blue);
        add(back);
        idl = new JLabel("ID:");
        idl.setBounds(10,10,200,30);
        add(idl);
        idl.setForeground(Color.white);
        id = new JTextField();
        id.setBounds(10,45,200,30);
        add(id);
        aircraft_id = new JLabel("AIRCRAFT:");
        aircraft_id.setBounds(10,85,200,30);
        add(aircraft_id);
        departure_city_idl = new JLabel("DEPARTURE CITY :");
        departure_city_idl.setBounds(10,160,200,30);
        add(departure_city_idl);
        departure_city_idl.setForeground(Color.white);
        departure_city_idcb = new JComboBox(idsss);
        departure_city_idcb.setBounds(10,200,200,30);
        add(departure_city_idcb);
        arrival_city_idl = new JLabel("ARRIVAL CITY ID:");
        arrival_city_idl.setBounds(150,235,200,30);
        add(arrival_city_idl);
        arrival_city_idl.setForeground(Color.white);
        arrival_city_idcb = new JComboBox(idsss);
        arrival_city_idcb.setBounds(150,270,200,30);
        add(arrival_city_idcb);
        departure_timel = new JLabel("DEPARTURE TIME:");
        departure_timel.setBounds(290,10,200,30);
        add(departure_timel);
        departure_timel.setForeground(Color.white);
        departure_time = new JTextField();
        departure_time.setBounds(290,45,200,30);
        add(departure_time);
        econom_place_pricel = new JLabel("ECONOM CLASS PRICE:");
        econom_place_pricel.setBounds(290,85,200,30);
        add(econom_place_pricel);
        econom_place_pricel.setForeground(Color.white);
        econom_place_price = new JTextField();
        econom_place_price.setBounds(290,120,200,30);
        add(econom_place_price);
        business_place_pricel = new JLabel("BUSINESS+ CLASS PRICE:");
        business_place_pricel.setBounds(290,160,200,30);
        add(business_place_pricel);
        business_place_pricel.setForeground(Color.white);
        business_place_price = new JTextField();
        business_place_price.setBounds(290,195,200,30);
        add(business_place_price);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                main.getAddFlight().setVisible(false);
                main.getAddpanel().setVisible(true);
            }
        });
        add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Flight flight = new Flight(Integer.parseInt(id.getText()), (main.sendList("aircrafts").get((aircraft_idcb.getSelectedIndex())).id), (main.sendListC("cities").get((departure_city_idcb.getSelectedIndex())).id), (main.sendListC("cities").get((arrival_city_idcb.getSelectedIndex())).id),Integer.parseInt(departure_time.getText()),Integer.parseInt(econom_place_price.getText()),Integer.parseInt(business_place_price.getText()));
                main.sendFlight(flight);
                id.setText("");
                aircraft_idcb.setSelectedItem(null);
                departure_city_idcb.setSelectedItem(null);
                arrival_city_idcb.setSelectedItem(null);
                departure_time.setText("");
                econom_place_price.setText("");
                business_place_price.setText("");
            }
        });
    }
}
