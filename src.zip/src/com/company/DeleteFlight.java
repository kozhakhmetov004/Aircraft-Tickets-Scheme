package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DeleteFlight extends JPanel {
    AdminFrame adminFrame;
    JButton delete;
    JButton back;
    JLabel idl;
    JTextField id;
    public DeleteFlight(AdminFrame adminFrame){
        this.adminFrame = adminFrame;
        setSize(520,500);
        setLayout(null);
        Color blue = new Color(18, 77, 114);
        Color grey = new Color(102, 102, 102);
        setBackground(grey);
        idl = new JLabel("ID:");
        idl.setBounds(100,200,300,30);
        add(idl);
        idl.setForeground(Color.white);
        id= new JTextField();
        id.setBounds(100,235,300,30);
        add(id);
        delete = new JButton("DELETE");
        delete.setBounds(125,400,100,30);
        delete.setBackground(blue);
        add(delete);
        back = new JButton("BACK");
        back.setBounds(275,400,100,30);
        back.setBackground(blue);
        add(back);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adminFrame.getDeleteFlight().setVisible(false);
                adminFrame.getDeletePanel().setVisible(true);
            }
        });
        delete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Flight flight = new Flight(Integer.parseInt(id.getText()),0,0,0,0,0,0);
                adminFrame.deleteFlight(flight);
                id.setText("");
            }
        });
    }
}
