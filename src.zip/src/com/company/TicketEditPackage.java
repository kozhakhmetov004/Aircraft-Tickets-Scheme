package com.company;

import java.io.Serializable;

public class TicketEditPackage implements Serializable {
    String parameter;
    Ticket ticket;
    int integer;
    String string;
    public TicketEditPackage(String parameter, Ticket ticket, int integer) {
        this.parameter = parameter;
        this.ticket = ticket;
        this.integer = integer;
    }

    public TicketEditPackage(String parameter, Ticket ticket, String string) {
        this.parameter = parameter;
        this.ticket = ticket;
        this.string = string;
    }
}
