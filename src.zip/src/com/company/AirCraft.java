package com.company;

import java.io.Serializable;

public class AirCraft implements Serializable {
    int id;
    String name;
    String model;
    int business_class_capacity;
    int econom_class_capacity;
    public AirCraft(int id, String name, String model, int business_class_capacity, int econom_class_capacity) {
        this.id = id;
        this.name = name;
        this.model = model;
        this.business_class_capacity = business_class_capacity;
        this.econom_class_capacity = econom_class_capacity;
    }
}
