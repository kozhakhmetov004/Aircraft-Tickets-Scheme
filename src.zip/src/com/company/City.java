package com.company;

import java.io.Serializable;

public class City implements Serializable {
    int id;
    String name;
    String country;
    String shot_name;

    public City(int id, String name, String country, String shot_name) {
        this.id = id;
        this.name = name;
        this.country = country;
        this.shot_name = shot_name;
    }
}
