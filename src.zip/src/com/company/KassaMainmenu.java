package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class KassaMainmenu extends JPanel {
    KassaFrame kassaFrame;
    JButton buy;
    JButton exit;
    JButton edit;
    Color red;
    ArrayList<String> impostorss = new ArrayList<>();
    ArrayList<String> impostorsss = new ArrayList<>();
    int b =0;
    int c =0;
    public KassaMainmenu(KassaFrame kassaFrame){
        this.kassaFrame = kassaFrame;
        setSize(520,500);
        setLayout(null);
        red = new Color(158, 4, 4);
        setBackground(red);
        exit = new JButton("EXIT");
        exit.setBounds(150,350,200,50);
        exit.setForeground(red);
        exit.setBackground(Color.white);
        add(exit);
        buy = new JButton("BUY TICKET");
        buy.setBounds(150,50,200,50);
        buy.setBackground(Color.white);
        buy.setForeground(red);
        add(buy);
        edit = new JButton("EDIT TICKETS");
        edit.setBounds(150,150,200,50);
        edit.setBackground(Color.white);
        edit.setForeground(red);
        add(edit);
        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        edit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                kassaFrame.getTicketMenu().setVisible(true);
                kassaFrame.getKassaMainmenu().setVisible(false);
            }
        });
        buy.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                kassaFrame.getKassaMainmenu().setVisible(false);
                kassaFrame.getBuyTicket().setVisible(true);
                String[] listen = new String[kassaFrame.sendList("aircrafts").size()];
                for(int i=0;i<kassaFrame.sendList("aircrafts").size();i++){
                    listen[i]= (String.valueOf(kassaFrame.sendList("aircrafts").get(i).id));
                }
                if(listen.length<kassaFrame.getBuyTicket().aircraft_id.getItemCount()){
                    ArrayList<String> impostors = new ArrayList<>();
                    for(int i = 0;i<kassaFrame.getBuyTicket().aircraft_id.getItemCount();i++){
                        int dursemes =0;
                        for(int j =0; j<listen.length;j++){
                            if(Integer.parseInt((String) kassaFrame.getBuyTicket().aircraft_id.getItemAt(i))!=Integer.parseInt(listen[j])){

                                dursemes++;
                            }
                        }
                        if(dursemes==listen.length){
                            impostors.add((String) kassaFrame.getBuyTicket().aircraft_id.getItemAt(i));
                        }


                    }

                        kassaFrame.getBuyTicket().aircraft_id.removeItem(impostors.get(c));
                    c++;

                }
                if(listen.length>kassaFrame.getBuyTicket().aircraft_id.getItemCount()) {
                    for(int i =0;i<(listen.length-kassaFrame.getBuyTicket().aircraft_id.getItemCount());i++){
                        impostorss.add(listen[listen.length-1-i]);
                    }
                    for(int i =0;i<(listen.length-kassaFrame.getBuyTicket().aircraft_id.getItemCount());i++){
                        kassaFrame.getBuyTicket().aircraft_id.addItem(impostorss.get(i));
                    }
                }
                String[] listen1 = new String[kassaFrame.sendListC("cities").size()];
                for(int i=0;i<kassaFrame.sendListC("cities").size();i++){
                    listen1[i]= (kassaFrame.sendListC("cities").get(i).name);
                }
                if(listen1.length<kassaFrame.getBuyTicket().departure_city.getItemCount()){
                    ArrayList<String> impostors = new ArrayList<>();
                    for(int i = 0;i<kassaFrame.getBuyTicket().departure_city.getItemCount();i++){
                        int dursemes =0;
                        for(int j =0; j<listen1.length;j++){
                            if( kassaFrame.getBuyTicket().departure_city.getItemAt(i).equals(listen1[j])){
                            }
                            else {
                                System.out.println(kassaFrame.getBuyTicket().departure_city.getItemAt(i) + " " + listen1[j]);
                                dursemes++;
                            }
                        }
                        if(dursemes==listen1.length){
                            impostors.add((String) kassaFrame.getBuyTicket().departure_city.getItemAt(i));
                        }


                    }
                    for (int i = 0; i < (kassaFrame.getBuyTicket().departure_city.getItemCount() - listen1.length); i++) {
                        kassaFrame.getBuyTicket().departure_city.removeItem(impostors.get(i));
                        kassaFrame.getBuyTicket().arrival_city.removeItem(impostors.get(i));
                    }

                }if(listen1.length>kassaFrame.getBuyTicket().departure_city.getItemCount()) {
                    for(int i =0;i<(listen1.length-kassaFrame.getBuyTicket().departure_city.getItemCount());i++){
                        impostorsss.add(listen1[listen1.length-1-i]);
                    }

                        kassaFrame.getBuyTicket().departure_city.addItem(impostorsss.get(b));
                        kassaFrame.getBuyTicket().arrival_city.addItem(impostorsss.get(b));
                    b++;

                }

            }
        });
    }
}
