package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class EditFlightParameter extends JPanel {
    AdminFrame adminFrame;
    JLabel idl;
    JButton back;
    JTextField id;
    JButton next;
    JLabel parameterl;
    JTextField parameter;
int a=0;
int b =0;
int c = 0;
    public EditFlightParameter(AdminFrame adminFrame){
        this.adminFrame = adminFrame;
        setSize(520,500);
        setLayout(null);
        Color blue = new Color(18, 77, 114);
        Color grey = new Color(102, 102, 102);
        setBackground(grey);
        idl = new JLabel("ID:");
        idl.setBounds(100,50,300,30);
        idl.setForeground(Color.white);
        add(idl);
        id= new JTextField();
        id.setBounds(100,100,300,30);
        add(id);
        parameterl = new JLabel("PARAMETER:");
        parameterl.setBounds(100,150,300,30);
        parameterl.setForeground(Color.white);
        add(parameterl);
        parameter = new JTextField();
        parameter.setBounds(100,200,300,30);
        add(parameter);
        back = new JButton("BACK");
        back.setBounds(275,400,100,30);
        back.setBackground(blue);
        back.setForeground(Color.white);
        add(back);
        next = new JButton("NEXT");
        next.setBounds(125,400,100,30);
        next.setBackground(blue);
        next.setForeground(Color.white);
        add(next);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adminFrame.getEditFlightParameter().setVisible(false);
                adminFrame.getEditPanel().setVisible(true);
            }
        });
        next.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(parameter.getText().equals("id")||parameter.getText().equals("departure_time") ||parameter.getText().equals("econom_place_price") || parameter.getText().equals("business_place_price")){
                    adminFrame.getEditFlightParameter().setVisible(false);
                    adminFrame.getEditFlightInt().setVisible(true);
                    if(parameter.getText().equals("id")){
                        adminFrame.getEditFlightInt().enterl.setText("ENTER ID:");
                    }if(parameter.getText().equals("departure_time")){
                        adminFrame.getEditFlightInt().enterl.setText("ENTER DEPARTURE TIME:");
                    }if(parameter.getText().equals("econom_place_price")){
                        adminFrame.getEditFlightInt().enterl.setText("ENTER ECONOM CLASS PRICE:");
                    }if(parameter.getText().equals("business_place_price")){
                        adminFrame.getEditFlightInt().enterl.setText("ENTER BUSINESS CLASS PRICE:");
                    }
                }if(parameter.getText().equals("departure_city_id")){
                    adminFrame.getEditFlightParameter().setVisible(false);
                    adminFrame.getEditFlightDepartureCityID().setVisible(true);
                    String[] listen = new String[adminFrame.sendListC("cities").size()];
                    for (int i = 0; i < adminFrame.sendListC("cities").size(); i++) {
                        listen[i] = String.valueOf(adminFrame.sendListC("cities").get(i).id);
                    }
                    if (listen.length > adminFrame.getEditFlightDepartureCityID().enter.getItemCount()) {
                        adminFrame.getEditFlightDepartureCityID().enter.addItem(listen[listen.length - 1]);
                    }
                    if (listen.length < adminFrame.getEditFlightDepartureCityID().enter.getItemCount()) {
                        ArrayList<String> impostors = new ArrayList<>();
                        for (int i = 0; i < adminFrame.getEditFlightDepartureCityID().enter.getItemCount(); i++) {
                            int dursemes = 0;
                            for (int j = 0; j < listen.length; j++) {
                                if ( adminFrame.getEditFlightDepartureCityID().enter.getItemAt(i).equals( listen[j])) {
                                }else {
                                    dursemes++;
                                }
                            }
                            if (dursemes == listen.length) {
                                impostors.add((String) adminFrame.getEditFlightDepartureCityID().enter.getItemAt(i));
                            }
                        }
                        adminFrame.getEditFlightDepartureCityID().enter.removeItem(impostors.get(b));
                        b++;
                    }
                }if(parameter.getText().equals("arrival_city_id")){
                        adminFrame.getEditFlightParameter().setVisible(false);
                        adminFrame.getEditFlightArrivalCityID().setVisible(true);
                        String[] listen = new String[adminFrame.sendListC("cities").size()];
                        for (int i = 0; i < adminFrame.sendListC("cities").size(); i++) {
                            listen[i] = String.valueOf(adminFrame.sendListC("cities").get(i).id);
                        }
                        if (listen.length > adminFrame.getEditFlightArrivalCityID().enter.getItemCount()) {
                            adminFrame.getEditFlightArrivalCityID().enter.addItem(listen[listen.length - 1]);
                        }
                        if (listen.length < adminFrame.getEditFlightArrivalCityID().enter.getItemCount()) {
                            ArrayList<String> impostors = new ArrayList<>();
                            for (int i = 0; i < adminFrame.getEditFlightArrivalCityID().enter.getItemCount(); i++) {
                                int dursemes = 0;
                                for (int j = 0; j < listen.length; j++) {
                                    if ( adminFrame.getEditFlightArrivalCityID().enter.getItemAt(i).equals( listen[j])) {
                                    }else {
                                        dursemes++;
                                    }
                                }
                                if (dursemes == listen.length) {
                                    impostors.add((String) adminFrame.getEditFlightArrivalCityID().enter.getItemAt(i));
                                }
                            }
                            adminFrame.getEditFlightArrivalCityID().enter.removeItem(impostors.get(c));
                            c++;
                        }
                }if(parameter.getText().equals("aircraft_id")) {
                    adminFrame.getEditFlightParameter().setVisible(false);
                    adminFrame.getEditFlightAircraftID().setVisible(true);
                    String[] listen = new String[adminFrame.sendList("aircrafts").size()];
                    for (int i = 0; i < adminFrame.sendList("aircrafts").size(); i++) {
                        listen[i] = String.valueOf(adminFrame.sendList("aircrafts").get(i).id);
                    }
                    if (listen.length > adminFrame.getEditFlightAircraftID().enter.getItemCount()) {
                        adminFrame.getEditFlightAircraftID().enter.addItem(listen[listen.length - 1]);
                    }
                    if (listen.length < adminFrame.getEditFlightAircraftID().enter.getItemCount()) {
                        ArrayList<String> impostors = new ArrayList<>();
                        for (int i = 0; i < adminFrame.getEditFlightAircraftID().enter.getItemCount(); i++) {
                            int dursemes = 0;
                            for (int j = 0; j < listen.length; j++) {
                                if ( adminFrame.getEditFlightAircraftID().enter.getItemAt(i).equals( listen[j])) {
                                }else {
                                    dursemes++;
                                }
                            }
                            if (dursemes == listen.length) {
                                impostors.add((String) adminFrame.getEditFlightAircraftID().enter.getItemAt(i));
                            }
                        }
                        adminFrame.getEditFlightAircraftID().enter.removeItem(impostors.get(a));
                        a++;
                    }
                }
            }

        });
    }
}
