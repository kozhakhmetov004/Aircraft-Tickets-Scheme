package com.company;



import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EditCityParameter extends JPanel {
    AdminFrame adminFrame;
    JLabel idl;
    JButton back;
    JTextField id;
    JButton next;
    JLabel parameterl;
    JTextField parameter;
    public EditCityParameter(AdminFrame adminFrame){
        this.adminFrame = adminFrame;
        setSize(520,500);
        setLayout(null);
        Color blue = new Color(18, 77, 114);
        Color grey = new Color(102, 102, 102);
        setBackground(grey);
        idl = new JLabel("ID:");
        idl.setBounds(100,50,300,30);
        idl.setForeground(Color.white);
        add(idl);
        id= new JTextField();
        id.setBounds(100,100,300,30);
        add(id);
        parameterl = new JLabel("PARAMETER:");
        parameterl.setBounds(100,150,300,30);
        parameterl.setForeground(Color.white);
        add(parameterl);
        parameter = new JTextField();
        parameter.setBounds(100,200,300,30);
        add(parameter);
        back = new JButton("BACK");
        back.setBounds(275,400,100,30);
        back.setBackground(blue);
        back.setForeground(Color.white);
        add(back);
        next = new JButton("NEXT");
        next.setBounds(125,400,100,30);
        next.setBackground(blue);
        next.setForeground(Color.white);
        add(next);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adminFrame.getEditCityParameter().setVisible(false);
                adminFrame.getEditPanel().setVisible(true);
            }
        });
        next.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(parameter.getText().equals("name") || parameter.getText().equals("country") || parameter.getText().equals("short_name")){
                    adminFrame.getEditCityParameter().setVisible(false);
                    adminFrame.getEditCityString().setVisible(true);
                }
                if(parameter.getText().equals("id")) {
                    adminFrame.getEditCityParameter().setVisible(false);
                    adminFrame.getEditCityInt().setVisible(true);
                }
            }
        });
    }
}
