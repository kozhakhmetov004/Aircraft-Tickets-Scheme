package com.company;

import javax.swing.*;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

public class KassaFrame extends JFrame {
    Socket socket;
    ObjectOutputStream ous;
    KassaMainmenu kassaMainmenu;
    TicketMenu ticketMenu;
    AddTicket addTicket;
    DeleteTicket deleteTicket;
    BuyTicket buyTicket;
    SearchTicket searchTicket;
    BuySelectedTicket buySelectedTicket;
    EditTicketParameter editTicketParameter;
    EditTicketFlightID editTicketFlightID;
    EditTicketInt editTicketInt;
    EditTicketString editTicketString;
    public KassaFrame(Socket socket){
        try {
            this.socket = socket;
            ous = new ObjectOutputStream(socket.getOutputStream());
        }catch(Exception e){
            e.printStackTrace();
        }
        setSize(520,500);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLayout(null);
        setTitle("KASSA");
        kassaMainmenu = new KassaMainmenu(this);
        kassaMainmenu.setVisible(true);
        add(kassaMainmenu);
        ticketMenu = new TicketMenu(this);
        ticketMenu.setVisible(false);
        add(ticketMenu);
        addTicket = new AddTicket(this);
        addTicket.setVisible(false);
        add(addTicket);
        deleteTicket = new DeleteTicket(this);
        deleteTicket.setVisible(false);
        add(deleteTicket);
        buyTicket = new BuyTicket(this);
        buyTicket.setVisible(false);
        add(buyTicket);
        searchTicket = new SearchTicket(this);
        searchTicket.setVisible(false);
        add(searchTicket);
        buySelectedTicket = new BuySelectedTicket(this);
        buySelectedTicket.setVisible(false);
        add(buySelectedTicket);
        editTicketParameter = new EditTicketParameter(this);
        editTicketParameter.setVisible(false);
        add(editTicketParameter);
        editTicketFlightID = new EditTicketFlightID(this);
        editTicketFlightID.setVisible(false);
        add(editTicketFlightID);
        editTicketInt = new EditTicketInt(this);
        editTicketInt.setVisible(false);
        add(editTicketInt);
        editTicketString = new EditTicketString(this);
        editTicketString.setVisible(false);
        add(editTicketString);
    }

    public EditTicketString getEditTicketString() {
        return editTicketString;
    }

    public EditTicketInt getEditTicketInt() {
        return editTicketInt;
    }

    public EditTicketFlightID getEditTicketFlightID() {
        return editTicketFlightID;
    }
    public void TicketEditInt(String parameter,Ticket ticket, int id){
        try {
            TicketEditPackage aep = new TicketEditPackage(parameter,ticket,id);
            ous.writeObject(aep);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }public void TicketEditString(String parameter,Ticket ticket, String string) {
        try {
            TicketEditPackage aep = new TicketEditPackage(parameter, ticket, string);
            ous.writeObject(aep);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public EditTicketParameter getEditTicketParameter() {
        return editTicketParameter;
    }

    public ObjectOutputStream getOus() {
        return ous;
    }

    public BuySelectedTicket getBuySelectedTicket() {
        return buySelectedTicket;
    }

    public Socket getSocket() {
        return socket;
    }

    public SearchTicket getSearchTicket() {
        return searchTicket;
    }

    public BuyTicket getBuyTicket() {
        return buyTicket;
    }

    public KassaMainmenu getKassaMainmenu() {
        return kassaMainmenu;
    }

    public TicketMenu getTicketMenu() {
        return ticketMenu;
    }

    public AddTicket getAddTicket() {
        return addTicket;
    }

    public DeleteTicket getDeleteTicket() {
        return deleteTicket;
    }
    public ArrayList<Flight> sendListF(String string){
        ArrayList<Flight> flights = null;
        try{
            ous.writeObject(string);
            ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
            flights = (ArrayList<Flight>) ois.readObject();
        }catch(Exception e){
            e.printStackTrace();
        }
        return flights;
    }
    public void sendTicket(Ticket ticket){
        try {
            TicketPackage tp = new TicketPackage("add",ticket);
            ous.writeObject(tp);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void deleteTicket(Ticket ticket) {
        try {
            TicketPackage fp = new TicketPackage("delete", ticket);
            ous.writeObject(fp);
        } catch (Exception e) {
            e.printStackTrace();
        }
    } public ArrayList<AirCraft> sendList(String string){
        ArrayList<AirCraft> aircrafts = null;
        try{
            ous.writeObject(string);
            ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
            aircrafts = (ArrayList<AirCraft>) ois.readObject();
        }catch(Exception e){
            e.printStackTrace();
        }
        return aircrafts;
    }
    public ArrayList<City> sendListC(String string){
        ArrayList<City> cities = null;
        try{
            ous.writeObject(string);
            ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
            cities = (ArrayList<City>) ois.readObject();
        }catch(Exception e){
            e.printStackTrace();
        }
        return cities;
    }public ArrayList<Ticket> sendListT(String string){
        ArrayList<Ticket> tickets = null;
        try{
            ous.writeObject(string);
            ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
            tickets = (ArrayList<Ticket>) ois.readObject();
        }catch(Exception e){
            e.printStackTrace();
        }
        return tickets;
    }
    public void sendAircraft(AirCraft airCraft) throws IOException {
        AircraftPackage ap = new AircraftPackage("add", airCraft);
        ous.writeObject(ap);

    }
    public void DeleteAircraft(AirCraft airCraft) {
        try {
            AircraftPackage ap = new AircraftPackage("delete", airCraft);
            ous.writeObject(ap);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
