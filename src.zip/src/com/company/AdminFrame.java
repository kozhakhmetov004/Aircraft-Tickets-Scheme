package com.company;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

public class AdminFrame extends JFrame {
    Mainmenu mainmenu;
    Addpanel addpanel;
    AddAircraft addAircraft;
    AddCity addCity;
    AddFlight addFlight;
    DeletePanel deletePanel;
    DeleteAircraft deleteAircraft;
    DeleteCity deleteCity;
    DeleteFlight deleteFlight;
    EditPanel editPanel;
    EditAircraftParameter editAircraftParameter;
    ObjectOutputStream ous;
    Socket socket ;
    EditAircraftInt editAircraftInt;
    EditAircraftString editAircraftString;
    EditCityParameter editCityParameter;
    EditCityInt editCityInt;
    EditCityString editCityString;
    EditFlightParameter editFlightParameter;
    EditFlightInt editFlightInt;
    EditFlightAircraftID editFlightAircraftID;
    EditFlightDepartureCityID editFlightDepartureCityID;
    EditFlightArrivalCityID editFlightArrivalCityID;
    Color blue = new Color(18, 77, 114);
    Color grey = new Color(102, 102, 102);
    public AdminFrame(Socket socket) {
        try {
            this.socket = socket;
            ous = new ObjectOutputStream(socket.getOutputStream());
        } catch (IOException e) {
            e.printStackTrace();
        }
        setSize(520, 500);
        setTitle("ADMIN");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLayout(null);
        mainmenu = new Mainmenu(this);
        mainmenu.setVisible(true);
        add(mainmenu);
        addpanel = new Addpanel(this);
        addpanel.setVisible(false);
        add(addpanel);
        deletePanel = new DeletePanel(this);
        deletePanel.setVisible(false);
        add(deletePanel);
        editPanel = new EditPanel(this);
        editPanel.setVisible(false);
        add(editPanel);
        editAircraftParameter = new EditAircraftParameter(this);
        editAircraftParameter.setVisible(false);
        add(editAircraftParameter);
        addAircraft = new AddAircraft(this);
        addAircraft.setVisible(false);
        add(addAircraft);
        addCity = new AddCity(this);
        addCity.setVisible(false);
        add(addCity);
        addFlight = new AddFlight(this);
        addFlight.setVisible(false);
        add(addFlight);
        deleteAircraft = new DeleteAircraft(this);
        deleteAircraft.setVisible(false);
        add(deleteAircraft);
        deleteCity = new DeleteCity(this);
        deleteCity.setVisible(false);
        add(deleteCity);
        deleteFlight = new DeleteFlight(this);
        deleteFlight.setVisible(false);
        add(deleteFlight);
        editAircraftInt = new EditAircraftInt(this);
        editAircraftInt.setVisible(false);
        add(editAircraftInt);
        editAircraftString = new EditAircraftString(this);
        editAircraftString.setVisible(false);
        add(editAircraftString);
        editCityParameter = new EditCityParameter(this);
        editCityParameter.setVisible(false);
        add(editCityParameter);
        editCityInt = new EditCityInt(this);
        editCityInt.setVisible(false);
        add(editCityInt);
        editCityString = new EditCityString(this);
        editCityString.setVisible(false);
        add(editCityString);
        editFlightParameter = new EditFlightParameter(this);
        editFlightParameter.setVisible(false);
        add(editFlightParameter);
        editFlightInt = new EditFlightInt(this);
        editFlightInt.setVisible(false);
        add(editFlightInt);
        editFlightAircraftID = new EditFlightAircraftID(this);
        editFlightAircraftID.setVisible(false);
        add(editFlightAircraftID);
        editFlightDepartureCityID = new EditFlightDepartureCityID(this);
        editFlightDepartureCityID.setVisible(false);
        add(editFlightDepartureCityID);
        editFlightArrivalCityID = new EditFlightArrivalCityID(this);
        editFlightArrivalCityID.setVisible(false);
        add(editFlightArrivalCityID);
    }
    public EditFlightDepartureCityID getEditFlightDepartureCityID() {
        return editFlightDepartureCityID;
    }
    public EditFlightArrivalCityID getEditFlightArrivalCityID() {
        return editFlightArrivalCityID;
    }
    public Color getBlue() {
        return blue;
    }
    public Color getGrey() {
        return grey;
    }
    public EditFlightAircraftID getEditFlightAircraftID() {
        return editFlightAircraftID;
    }
    public EditFlightInt getEditFlightInt() {
        return editFlightInt;
    }
    public EditFlightParameter getEditFlightParameter() {
        return editFlightParameter;
    }
    public EditCityInt getEditCityInt() {
        return editCityInt;
    }
    public EditCityString getEditCityString() {
        return editCityString;
    }
    public EditCityParameter getEditCityParameter() {
        return editCityParameter;
    }
    public EditAircraftInt getEditAircraftInt() {
        return editAircraftInt;
    }
    public EditAircraftString getEditAircraftString() {
        return editAircraftString;
    }
    public Mainmenu getMainmenu() {
        return mainmenu;
    }
    public Addpanel getAddpanel() {
        return addpanel;
    }
    public AddAircraft getAddAircraft() {
        return addAircraft;
    }
    public AddCity getAddCity() {
        return addCity;
    }
    public AddFlight getAddFlight() {
        return addFlight;
    }
    public DeletePanel getDeletePanel() {
        return deletePanel;
    }
    public DeleteAircraft getDeleteAircraft() {
        return deleteAircraft;
    }
    public DeleteCity getDeleteCity() {
        return deleteCity;
    }
    public EditPanel getEditPanel() {
        return editPanel;
    }
    public EditAircraftParameter getEditAircraftParameter() {
        return editAircraftParameter;
    }
    public DeleteFlight getDeleteFlight() {
        return deleteFlight;
    }
    public void DeleteAircraft(AirCraft airCraft) {
        try {
            AircraftPackage ap = new AircraftPackage("delete", airCraft);
            ous.writeObject(ap);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void DeleteCity(City city) {
        try {
            CityPackage cp = new CityPackage("delete", city);
            ous.writeObject(cp);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void deleteFlight(Flight flight) {
        try {
            FlightPackage fp = new FlightPackage("delete", flight);
            ous.writeObject(fp);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void sendAircraft(AirCraft airCraft) throws IOException {
        AircraftPackage ap = new AircraftPackage("add", airCraft);
        ous.writeObject(ap);
    }
    public void sendCity(City city){
        try {
            CityPackage cp = new CityPackage("add", city);
            ous.writeObject(cp);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    public void sendFlight(Flight flight){
        try {
            FlightPackage fp = new FlightPackage("add", flight);
            ous.writeObject(fp);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    public ArrayList<AirCraft> sendList(String string){
        ArrayList<AirCraft> aircrafts = null;
        try{
            ous.writeObject(string);
            ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
            aircrafts = (ArrayList<AirCraft>) ois.readObject();
        }catch(Exception e){
            e.printStackTrace();
        }
        return aircrafts;
    }
    public ArrayList<City> sendListC(String string){
        ArrayList<City> cities = null;
        try{
            ous.writeObject(string);
            ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
            cities = (ArrayList<City>) ois.readObject();
        }catch(Exception e){
            e.printStackTrace();
        }
        return cities;
    }public void AircraftEditInt(String parameter,AirCraft airCraft, int id){
        try {
            AircraftEditPackage aep = new AircraftEditPackage(parameter,airCraft,id);
            ous.writeObject(aep);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void FlightEditInt(String parameter,Flight flight, int id){
        try {
            FlightEditPackage fep = new FlightEditPackage(parameter,flight,id);
            ous.writeObject(fep);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }public void CityEditInt(String parameter,City city, int id){
        try {
            CityEditPackage cep = new CityEditPackage(parameter,city,id);
            ous.writeObject(cep);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void AircraftEditString(String parameter,AirCraft airCraft, String string){
        try {
            AircraftEditPackage aep = new AircraftEditPackage(parameter,airCraft,string);
            ous.writeObject(aep);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }public void CityEditString(String parameter,City city, String string){
        try {
            CityEditPackage aep = new CityEditPackage(parameter,city,string);
            ous.writeObject(aep);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public ArrayList<Flight> sendListF(String string){
        ArrayList<Flight> aircrafts = null;
        try{
            ous.writeObject(string);
            ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
            aircrafts = (ArrayList<Flight>) ois.readObject();
        }catch(Exception e){
            e.printStackTrace();
        }
        return aircrafts;
    }
}
