package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddAircraft extends JPanel {
    AdminFrame adminFrame;
    JTextField id;
    JTextField name	;
    JTextField model;
    JTextField business_class_capacity;
    JTextField econom_class_capacity;
    JButton add;
    JButton back;
    JLabel idl;
    JLabel namel;
    JLabel modell;
    JLabel business_class_capacityl;
    JLabel econom_class_capacityl;
    public AddAircraft(AdminFrame adminFrame){
        this.adminFrame = adminFrame;
        setSize(520,500);
        setLayout(null);
        Color blue = new Color(18, 77, 114);
        Color grey = new Color(102, 102, 102);
        setBackground(grey);
        idl = new JLabel("ID:");
        idl.setBounds(100,10,200,30);
        idl.setForeground(Color.white);
        add(idl);
        id = new JTextField();
        id.setBounds(100,45,300,30);
        add(id);
        namel = new JLabel("NAME:");
        namel.setBounds(100,85,200,30);
        namel.setForeground(Color.white);
        add(namel);
        name = new JTextField();
        name.setBounds(100,120,300,30);
        add(name);
        modell = new JLabel("MODEL:");
        modell.setBounds(100,160,200,30);
        modell.setForeground(Color.white);
        add(modell);
        model = new JTextField();
        model.setBounds(100,195,300,30);
        add(model);
        business_class_capacityl = new JLabel("BUS CLASS CAP:");
        business_class_capacityl.setBounds(100,235,200,30);
        business_class_capacityl.setForeground(Color.white);
        add(business_class_capacityl);
        business_class_capacity = new JTextField();
        business_class_capacity.setBounds(100,270,300,30);
        add(business_class_capacity);
        econom_class_capacityl = new JLabel("ECO CLASS CAP:");
        econom_class_capacityl.setBounds(100,310,200,30);
        econom_class_capacityl.setForeground(Color.white);
        add(econom_class_capacityl);
        econom_class_capacity = new JTextField();
        econom_class_capacity.setBounds(100,345,300,30);
        add(econom_class_capacity);
        add = new JButton("ADD");
        add.setBounds(125,400,100,30);
        add.setBackground(blue);
        add(add);
        back = new JButton("BACK");
        back.setBounds(275,400,100,30);
        back.setBackground(blue);
        add(back);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adminFrame.getAddAircraft().setVisible(false);
                adminFrame.getAddpanel().setVisible(true);
            }
        });
        add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    AirCraft aircraft = new AirCraft(Integer.parseInt(id.getText()),name.getText(),model.getText(),Integer.parseInt(business_class_capacity.getText()),Integer.parseInt(econom_class_capacity.getText()));
                    adminFrame.sendAircraft(aircraft);
                    adminFrame.getAddFlight().aircraft_idcb.addItem(aircraft.name);
                    id.setText("");
                    name.setText("");
                    business_class_capacity.setText("");
                    model.setText("");
                    econom_class_capacity.setText("");
                } catch (Exception s) {
                    s.printStackTrace();
                }
            }
        });
    }
}
