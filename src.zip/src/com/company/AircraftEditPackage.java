package com.company;

import java.io.Serializable;

public class AircraftEditPackage implements Serializable {
    String parameter;
    AirCraft airCraft;
    int integer;
    String string;
    public AircraftEditPackage(String parameter,AirCraft airCraft, int integer) {
        this.parameter =parameter;
        this.airCraft = airCraft;
        this.integer = integer;
    }
    public AircraftEditPackage(String parameter, AirCraft airCraft, String string) {
        this.parameter = parameter;
        this.airCraft = airCraft;
        this.string = string;
    }
}
