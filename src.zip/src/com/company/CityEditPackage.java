package com.company;

import java.io.Serializable;

public class CityEditPackage implements Serializable {
    String parameter;
    City city;
    int integer;
    String string;

    public CityEditPackage(String parameter,City city, int integer) {
        this.parameter =parameter;
        this.city = city;
        this.integer = integer;
    }

    public CityEditPackage(String parameter, City city, String string) {
        this.parameter = parameter;
        this.city = city;
        this.string = string;
    }
}
