package com.company;


import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class AdminThreadOKU extends Thread {
    Socket socket;
    ObjectInputStream ois;
    public static Connection connection;
    public AdminThreadOKU(Socket socket, Connection connection) {
        this.connection = connection;
        this.socket = socket;
        try {
            ois = new ObjectInputStream(socket.getInputStream());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @Override
    public void run() {
        try {
            while (true) {
                try {
                    Object object = ois.readObject();
                    if (object instanceof AircraftPackage) {
                        AircraftPackage ap = (AircraftPackage) object;
                        if (ap.operationType.equals("add")) {
                            AddAircraft(ap.airCraft);
                        }
                        if (ap.operationType.equals("delete")) {
                            DeleteAircraft(ap.airCraft);
                        }
                    }
                    if (object instanceof CityPackage) {
                        CityPackage cp = (CityPackage) object;
                        if (cp.operationType.equals("add")) {
                            AddCity(cp.city);
                        }
                        if (cp.operationType.equals("delete")) {
                            deleteCity(cp.city);
                        }
                    }
                    if (object instanceof String) {
                        if (object.equals("aircrafts")) {
                            ObjectOutputStream ous = new ObjectOutputStream(socket.getOutputStream());
                            ous.writeObject(AircraftData());
                        }
                        if (object.equals("cities")) {
                            ObjectOutputStream ous = new ObjectOutputStream(socket.getOutputStream());
                            ous.writeObject(CityData());
                        }if(object.equals("flights")){
                            ObjectOutputStream ous = new ObjectOutputStream(socket.getOutputStream());
                            ous.writeObject(FlightData());
                        }
                    }
                    if (object instanceof FlightPackage) {
                        FlightPackage fp = (FlightPackage) object;
                        if (fp.operationType.equals("add")) {
                            AddFlight(fp.flight);
                        }if(fp.operationType.equals("delete")){
                            deleteFlight(fp.flight);
                        }
                    }if(object instanceof AircraftEditPackage){
                        AircraftEditPackage aep = (AircraftEditPackage) object;
                        if(aep.parameter.equals("id")) {
                            DeleteAircraft(aep.airCraft);
                            AirCraft airCraft = new AirCraft(aep.integer, aep.airCraft.name, aep.airCraft.model, aep.airCraft.business_class_capacity, aep.airCraft.econom_class_capacity);
                            AddAircraft(airCraft);
                        }if(aep.parameter.equals("business_class_capacity")){
                            DeleteAircraft(aep.airCraft);
                            AirCraft airCraft = new AirCraft(aep.airCraft.id, aep.airCraft.name, aep.airCraft.model, aep.integer, aep.airCraft.econom_class_capacity);
                            AddAircraft(airCraft);
                        }if(aep.parameter.equals("econom_class_capacity")){
                            DeleteAircraft(aep.airCraft);
                            AirCraft airCraft = new AirCraft(aep.airCraft.id, aep.airCraft.name, aep.airCraft.model, aep.airCraft.business_class_capacity, aep.integer);
                            AddAircraft(airCraft);
                        }if(aep.parameter.equals("name")){
                            DeleteAircraft(aep.airCraft);
                            AirCraft airCraft = new AirCraft(aep.airCraft.id, aep.string, aep.airCraft.model, aep.airCraft.business_class_capacity, aep.airCraft.econom_class_capacity);
                            AddAircraft(airCraft);
                        }if(aep.parameter.equals("model")){
                            DeleteAircraft(aep.airCraft);
                            AirCraft airCraft = new AirCraft(aep.airCraft.id, aep.airCraft.name, aep.string, aep.airCraft.business_class_capacity, aep.airCraft.econom_class_capacity);
                            AddAircraft(airCraft);
                        }
                    }
                    if(object instanceof CityEditPackage) {
                        CityEditPackage cep = (CityEditPackage) object;
                        if(cep.parameter.equals("id")) {
                            deleteCity(cep.city);
                            City city = new City(cep.integer, cep.city.name, cep.city.country, cep.city.shot_name);
                            AddCity(city);
                        }if(cep.parameter.equals("name")){
                            deleteCity(cep.city);
                            City city = new City(cep.city.id, cep.string, cep.city.country, cep.city.shot_name);
                            AddCity(city);
                        }if(cep.parameter.equals("country")){
                            deleteCity(cep.city);
                            City city = new City(cep.city.id, cep.city.name, cep.string, cep.city.shot_name);
                            AddCity(city);
                        }if(cep.parameter.equals("short_name")){
                            deleteCity(cep.city);
                            City city = new City(cep.city.id, cep.city.name, cep.city.country, cep.string);
                            AddCity(city);
                        }
                    }if(object instanceof FlightEditPackage){
                        FlightEditPackage fep = (FlightEditPackage)object;
                        if(fep.parameter.equals("id")){
                            deleteFlight(fep.flight);
                            Flight flight = new Flight(fep.integer,fep.flight.aircraft_id,fep.flight.departurecityid,fep.flight.arrivalcityid,fep.flight.time,fep.flight.econom_class_price,fep.flight.bysiness_class_price);
                            AddFlight(flight);
                        }if(fep.parameter.equals("departure_time")){
                            deleteFlight(fep.flight);
                            Flight flight = new Flight(fep.flight.id,fep.flight.aircraft_id,fep.flight.departurecityid,fep.flight.arrivalcityid,fep.integer,fep.flight.econom_class_price,fep.flight.bysiness_class_price);
                            AddFlight(flight);
                        }if(fep.parameter.equals("econom_place_price")){
                            deleteFlight(fep.flight);
                            Flight flight = new Flight(fep.flight.id, fep.flight.aircraft_id,fep.flight.departurecityid,fep.flight.arrivalcityid,fep.flight.time,fep.integer,fep.flight.bysiness_class_price);
                            AddFlight(flight);
                        }if(fep.parameter.equals("business_place_price")){
                            deleteFlight(fep.flight);
                            Flight flight = new Flight(fep.flight.id, fep.flight.aircraft_id,fep.flight.departurecityid,fep.flight.arrivalcityid,fep.flight.time,fep.flight.econom_class_price,fep.integer);
                            AddFlight(flight);
                        }
                        if(fep.parameter.equals("aircraft_id")){
                            deleteFlight(fep.flight);
                            Flight flight = new Flight(fep.flight.id, fep.integer,fep.flight.departurecityid,fep.flight.arrivalcityid,fep.flight.time,fep.flight.econom_class_price,fep.flight.bysiness_class_price);
                            AddFlight(flight);
                        }
                        if(fep.parameter.equals("departure_city_id")){
                            deleteFlight(fep.flight);
                            Flight flight = new Flight(fep.flight.id, fep.flight.aircraft_id, fep.integer,fep.flight.arrivalcityid,fep.flight.time,fep.flight.econom_class_price,fep.flight.bysiness_class_price);
                            AddFlight(flight);
                        }
                        if(fep.parameter.equals("arrival_city_id")){
                            deleteFlight(fep.flight);
                            Flight flight = new Flight(fep.flight.id, fep.flight.aircraft_id, fep.flight.departurecityid,fep.integer,fep.flight.time,fep.flight.econom_class_price,fep.flight.bysiness_class_price);
                            AddFlight(flight);
                        }
                    }
                } catch (Exception e) {
                }
            }
        } catch (Exception e) {
        }
    }
    public void AddAircraft(AirCraft aircraft) {
        try {
            PreparedStatement st = connection.prepareStatement("INSERT INTO aircrafts(id,name,model,business_class_capacity,econom_class_capacity)VALUES(?,?,?,?,?)");
            st.setInt(1, aircraft.id);
            st.setString(2, aircraft.name);
            st.setString(3, aircraft.model);
            st.setInt(4, aircraft.business_class_capacity);
            st.setInt(5, aircraft.econom_class_capacity);
            st.execute();
            st.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void DeleteAircraft(AirCraft airCraft) {
        try {
            PreparedStatement st = connection.prepareStatement("DELETE FROM aircrafts where name = ?");
            st.setString(1, airCraft.name);
            st.execute();
            st.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void AddCity(City city) {
        try {
            PreparedStatement st = connection.prepareStatement("INSERT INTO cities (id,name,country,short_name)VALUES(?,?,?,?)");
            st.setInt(1, city.id);
            st.setString(2, city.name);
            st.setString(3, city.country);
            st.setString(4, city.shot_name);
            st.execute();
            st.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void deleteCity(City city) {
        try {
            PreparedStatement st = connection.prepareStatement("DELETE FROM cities where id = ?");
            st.setInt(1, city.id);
            st.execute();
            st.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void deleteFlight(Flight flight) {
        try {
            PreparedStatement st = connection.prepareStatement("DELETE FROM flights where id = ?");
            st.setInt(1, flight.id);
            st.execute();
            st.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public ArrayList<AirCraft> AircraftData() {
        ArrayList<AirCraft> aircrafts = new ArrayList<>();
        try {
            PreparedStatement st = connection.prepareStatement("SELECT * FROM aircrafts");
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String model = rs.getString("model");
                int business_class_capacity = rs.getInt("business_class_capacity");
                int econom_class_capacity = rs.getInt("econom_class_capacity");
                aircrafts.add(new AirCraft(id, name, model, business_class_capacity, econom_class_capacity));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return aircrafts;
    }
    public ArrayList<City> CityData() {
        ArrayList<City> cities = new ArrayList<>();
        try {
            PreparedStatement st = connection.prepareStatement("SELECT * FROM cities");
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String country = rs.getString("country");
                String short_name = rs.getString("short_name");
                cities.add(new City(id, name, country, short_name));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cities;
    }
    public void AddFlight(Flight flight) {
        try {
            PreparedStatement st = connection.prepareStatement("INSERT INTO flights(id,aircraft_id,departure_city_id,arrival_city_id,departure_time,econom_place_price,business_place_price)VALUES(?,?,?,?,?,?,?)");
            st.setInt(1, flight.id);
            st.setInt(2, (flight.aircraft_id));
            st.setInt(3, (flight.departurecityid));
            st.setInt(4, (flight.arrivalcityid));
            st.setInt(5, flight.time);
            st.setInt(6, flight.econom_class_price);
            st.setInt(7, flight.bysiness_class_price);
            st.execute();
            st.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }public ArrayList<Flight> FlightData(){
        ArrayList<Flight> flights = new ArrayList<>();
        try {
            PreparedStatement st = connection.prepareStatement("SELECT * FROM flights");
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                int aircraft_id = rs.getInt("aircraft_id");
                int departure_city_id = rs.getInt("departure_city_id");
                int arrival_city_id = rs.getInt("arrival_city_id");
                int departure_time = rs.getInt("departure_time");
                int econom_place_capacity = rs.getInt("econom_place_price");
                int business_place_price = rs.getInt("business_place_price");
                flights.add(new Flight(id, aircraft_id, departure_city_id, arrival_city_id,departure_time,econom_place_capacity,business_place_price));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flights;
    }
}
