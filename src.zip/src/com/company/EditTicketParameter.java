package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class EditTicketParameter extends JPanel {
    KassaFrame kassaFrame;
    JLabel idl;
    JButton back;
    JTextField id;
    JButton next;
    JLabel parameterl;
    JTextField parameter;
    int b =0;
    public EditTicketParameter(KassaFrame kassaFrame) {
        this.kassaFrame = kassaFrame;
        setSize(520, 500);
        setLayout(null);
        setBackground(kassaFrame.getKassaMainmenu().red);
        idl = new JLabel("ID:");
        idl.setBounds(100, 50, 300, 30);
        idl.setForeground(Color.white);
        add(idl);
        id = new JTextField();
        id.setBounds(100, 100, 300, 30);
        id.setBackground(Color.white);
        id.setForeground(kassaFrame.getKassaMainmenu().red);
        add(id);
        parameterl = new JLabel("PARAMETER:");
        parameterl.setBounds(100, 150, 300, 30);
        parameterl.setForeground(Color.white);
        add(parameterl);
        parameter = new JTextField();
        parameter.setBounds(100, 200, 300, 30);
        parameter.setForeground(kassaFrame.getKassaMainmenu().red);
        parameter.setBackground(Color.white);
        add(parameter);
        back = new JButton("BACK");
        back.setBounds(275, 400, 100, 30);
        back.setBackground(Color.white);
        back.setForeground(kassaFrame.getKassaMainmenu().red);
        add(back);
        next = new JButton("NEXT");
        next.setBounds(125, 400, 100, 30);
        next.setBackground(Color.white);
        next.setForeground(kassaFrame.getKassaMainmenu().red);
        add(next);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                kassaFrame.getEditTicketParameter().setVisible(false);
                kassaFrame.getTicketMenu().setVisible(true);
            }
        });
        next.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (parameter.getText().equals("flight_id")) {
                    kassaFrame.getEditTicketParameter().setVisible(false);
                    kassaFrame.getEditTicketFlightID().setVisible(true);
                    String[] listen = new String[kassaFrame.sendListF("flights").size()];
                    for (int i = 0; i < kassaFrame.sendListC("flights").size(); i++) {
                        listen[i] = String.valueOf(kassaFrame.sendListF("flights").get(i).id);
                    }
                    if (listen.length > kassaFrame.getEditTicketFlightID().enter.getItemCount()) {
                        kassaFrame.getEditTicketFlightID().enter.addItem(listen[listen.length - 1]);
                    }
                    if (listen.length < kassaFrame.getEditTicketFlightID().enter.getItemCount()) {
                        ArrayList<String> impostors = new ArrayList<>();
                        for (int i = 0; i < kassaFrame.getEditTicketFlightID().enter.getItemCount(); i++) {
                            int dursemes = 0;
                            for (int j = 0; j < listen.length; j++) {
                                if (kassaFrame.getEditTicketFlightID().enter.getItemAt(i).equals(listen[j])) {
                                } else {
                                    dursemes++;
                                }
                            }
                            if (dursemes == listen.length) {
                                impostors.add((String) kassaFrame.getEditTicketFlightID().enter.getItemAt(i));
                            }
                        }
                        kassaFrame.getEditTicketFlightID().enter.removeItem(impostors.get(b));
                        b++;
                    }
                }
                if(parameter.getText().equals("id")) {
                    kassaFrame.getEditTicketParameter().setVisible(false);
                    kassaFrame.getEditTicketInt().setVisible(true);
                    if (parameter.getText().equals("id")) {
                        kassaFrame.getEditTicketInt().enterl.setText("ENTER ID:");
                        kassaFrame.getEditTicketInt().error.setVisible(false);
                    }
                }if(parameter.getText().equals("name")||parameter.getText().equals("surname")||parameter.getText().equals("passport_number")||parameter.getText().equals("ticket_type")) {
                    kassaFrame.getEditTicketParameter().setVisible(false);
                    kassaFrame.getEditTicketString().setVisible(true);
                    if (parameter.getText().equals("name")) {
                        kassaFrame.getEditTicketString().enterl.setText("ENTER NAME:");
                        kassaFrame.getEditTicketString().ticket_Type.setVisible(false);
                        kassaFrame.getEditTicketString().enter.setVisible(true);
                    }if (parameter.getText().equals("surname")) {
                        kassaFrame.getEditTicketString().enterl.setText("ENTER SURNAME:");
                        kassaFrame.getEditTicketString().ticket_Type.setVisible(false);
                        kassaFrame.getEditTicketString().enter.setVisible(true);
                    }if (parameter.getText().equals("passport_number")) {
                        kassaFrame.getEditTicketString().enterl.setText("ENTER PASSPORT NUMBER:");
                        kassaFrame.getEditTicketString().ticket_Type.setVisible(false);
                        kassaFrame.getEditTicketString().enter.setVisible(true);
                    }if (parameter.getText().equals("ticket_type")) {
                        kassaFrame.getEditTicketString().enterl.setText("CHOOSE TICKET TYPE:");
                        kassaFrame.getEditTicketString().ticket_Type.setVisible(true);
                        kassaFrame.getEditTicketString().enter.setVisible(false);
                    }
                }
            }
        });
    }
}
