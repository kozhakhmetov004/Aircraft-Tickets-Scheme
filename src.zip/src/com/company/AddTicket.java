package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddTicket extends JPanel {
    KassaFrame kassaFrame;
    JButton back;
    JButton add;
    JLabel flight_idl;
    JComboBox flight_id;
    JLabel idl;
    JTextField id;
    JLabel namel;
    JTextField name;
    JLabel surnamel;
    JTextField surname;
    JLabel passport_numberl;
    JTextField passport_number;
    JLabel ticket_typel;
    JComboBox ticket_type;
    String[] type = new String[2];
    String[] flight_ids;
    public AddTicket(KassaFrame kassaFrame){
        type[0]= "ec";
        type[1]="bc";
        this.kassaFrame = kassaFrame;
        setSize(520,500);
        setLayout(null);
        setBackground(kassaFrame.getKassaMainmenu().red);
        flight_ids = new String[kassaFrame.sendListF("flights").size()];
        for(int i =0;i <kassaFrame.sendListF("flights").size();i++){
            flight_ids[i] = String.valueOf(kassaFrame.sendListF("flights").get(i).id);
        }
        flight_id = new JComboBox(flight_ids);
        flight_id.setBounds(10,120,200,30);
        flight_id.setBackground(Color.white);
        flight_id.setForeground(kassaFrame.getKassaMainmenu().red);
        add(flight_id);
        flight_id.setSelectedItem(null);
        add = new JButton("ADD");
        add.setBounds(125,400,100,30);
        add.setForeground(kassaFrame.getKassaMainmenu().red);
        add.setBackground(Color.white);
        add(add);
        back = new JButton("BACK");
        back.setBounds(275,400,100,30);
        back.setForeground(kassaFrame.getKassaMainmenu().red);
        back.setBackground(Color.white);
        add(back);
        idl = new JLabel("ID:");
        idl.setBounds(10,10,200,30);
        idl.setForeground(Color.white);
        add(idl);
        id = new JTextField();
        id.setBounds(10,45,200,30);
        id.setBackground(Color.white);
        id.setForeground(kassaFrame.getKassaMainmenu().red);
        add(id);
        flight_idl = new JLabel("FLIGHT:");
        flight_idl.setBounds(10,85,200,30);
        flight_idl.setForeground(Color.white);
        add(flight_idl);
        namel = new JLabel("NAME:");
        namel.setBounds(10,160,200,30);
        namel.setForeground(Color.white);
        add(namel);
        name = new JTextField();
        name.setBounds(10,195,200,30);
        name.setBackground(Color.white);
        name.setForeground(kassaFrame.getKassaMainmenu().red);
        add(name);
        surnamel = new JLabel("SURNAME:");
        surnamel.setBounds(290,10,200,30);
        surnamel.setForeground(Color.white);
        add(surnamel);
        surname = new JTextField();
        surname.setBounds(290,45,200,30);
        surname.setBackground(Color.white);
        surname.setForeground(kassaFrame.getKassaMainmenu().red);
        add(surname);
        passport_numberl = new JLabel("PASSPORT NUMBER:");
        passport_numberl.setBounds(290,85,200,30);
        passport_numberl.setForeground(Color.white);
        add(passport_numberl);
        passport_number = new JTextField();
        passport_number.setBounds(290,120,200,30);
        passport_number.setBackground(Color.white);
        passport_number.setForeground(kassaFrame.getKassaMainmenu().red);
        add(passport_number);
        ticket_type = new JComboBox(type);
        ticket_type.setBounds(290,195,200,30);
        ticket_type.setBackground(Color.white);
        ticket_type.setForeground(kassaFrame.getKassaMainmenu().red);
        add(ticket_type);
        ticket_type.setSelectedItem(null);
        ticket_typel = new JLabel("TICKET TYPE:");
        ticket_typel.setBounds(290,160,200,30);
        ticket_typel.setBackground(Color.white);
        ticket_typel.setForeground(kassaFrame.getKassaMainmenu().red);
        add(ticket_typel);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                kassaFrame.getTicketMenu().setVisible(true);
                kassaFrame.getAddTicket().setVisible(false);
            }
        });
        add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Ticket ticket = new Ticket(Integer.parseInt(id.getText()),kassaFrame.sendListF("flights").get(flight_id.getSelectedIndex()).id,name.getText(),surname.getText(),passport_number.getText(), type[ticket_type.getSelectedIndex()]);
                kassaFrame.sendTicket(ticket);
                id.setText("");
                flight_id.setSelectedItem(null);
                name.setText("");
                surname.setText("");
                passport_number.setText("");
                ticket_type.setSelectedItem(null);
            }
        });
    }
}
