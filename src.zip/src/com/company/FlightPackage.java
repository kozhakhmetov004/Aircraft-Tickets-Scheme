package com.company;

import java.io.Serializable;

public class FlightPackage implements Serializable {
    String operationType;
    Flight flight;

    public FlightPackage(String operationType, Flight flight) {
        this.operationType = operationType;
        this.flight = flight;
    }
}
