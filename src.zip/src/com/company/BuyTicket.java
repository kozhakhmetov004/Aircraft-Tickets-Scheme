package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class BuyTicket extends JPanel {
    KassaFrame kassaFrame;
    JButton back;
    JComboBox aircraft_id;
    JLabel aircraft_idl;
    JComboBox departure_city;
    JLabel departure_cityl;
    JComboBox arrival_city;
    JLabel arrival_cityl;
    JButton search;
    ArrayList<Integer> available_flight_ids;
    JLabel error;
    ArrayList<Integer> available_tickets_id;
    public BuyTicket(KassaFrame kassaFrame){
        this.kassaFrame = kassaFrame;
        setSize(520,520);
        setLayout(null);
        setBackground(kassaFrame.getKassaMainmenu().red);
        back = new JButton("BACK");
        back.setBounds(275,400,200,50);
        back.setForeground(kassaFrame.getKassaMainmenu().red);
        back.setBackground(Color.white);
        add(back);
        search = new JButton("SEARCH FOR TICKET");
        search.setBounds(25,400,200,50);
        search.setForeground(kassaFrame.getKassaMainmenu().red);
        search.setBackground(Color.white);
        add(search);
        aircraft_idl = new JLabel("AIRCRAFT:");
        aircraft_idl.setBounds(100,20,300,30);
        aircraft_idl.setForeground(Color.white);
        add(aircraft_idl);
        error = new JLabel("NO TICKETS WITH YOUR SETTINGS");
        error.setBounds(100,300,300,30);
        error.setForeground(Color.white);
        add(error);
        error.setVisible(false);
        String[] aircraft_ids = new String[kassaFrame.sendList("aircrafts").size()];
        for(int i=0;i<kassaFrame.sendList("aircrafts").size();i++){
            aircraft_ids[i]= (String.valueOf(kassaFrame.sendList("aircrafts").get(i).id));
        }
        aircraft_id = new JComboBox(aircraft_ids);
        aircraft_id.setBounds(100,50,300,30);
        aircraft_id.setSelectedItem(null);
        aircraft_id.setBackground(Color.white);
        aircraft_id.setForeground(kassaFrame.getKassaMainmenu().red);
        add(aircraft_id);
        String[] aircraft_idss = new String[kassaFrame.sendListC("cities").size()];
        for(int i=0;i<kassaFrame.sendListC("cities").size();i++) {
            aircraft_idss[i] = (String.valueOf(kassaFrame.sendListC("cities").get(i).id));
        }
        departure_cityl = new JLabel("DEPARTURE CITY ID:");
        departure_cityl.setBounds(100,100,300,30);
        departure_cityl.setForeground(Color.white);
        add(departure_cityl);
        departure_city = new JComboBox(aircraft_idss);
        departure_city.setSelectedItem(null);
        departure_city.setBounds(100,150,300,30);
        departure_city.setBackground(Color.white);
        departure_city.setForeground(kassaFrame.getKassaMainmenu().red);
        add(departure_city);
        arrival_cityl = new JLabel("ARRIVAL CITY ID:");
        arrival_cityl.setBounds(100,200,300,30);
        arrival_cityl.setForeground(Color.white);
        add(arrival_cityl);
        arrival_city = new JComboBox(aircraft_idss);
        arrival_city.setSelectedItem(null);
        arrival_city.setBounds(100,250,300,30);
        arrival_city.setBackground(Color.white);
        arrival_city.setForeground(kassaFrame.getKassaMainmenu().red);
        add(arrival_city);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                kassaFrame.getBuyTicket().setVisible(false);
                kassaFrame.getKassaMainmenu().setVisible(true);
            }
        });
        aircraft_id.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                error.setVisible(false);
            }
        });
        departure_city.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                error.setVisible(false);
            }
        });
        arrival_city.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                error.setVisible(false);
            }
        });
        search.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                available_flight_ids = new ArrayList<>();
                available_tickets_id=new ArrayList<>();
                int z=0;
                for(int i=0;i<kassaFrame.sendListF("flights").size();i++){
                    if(kassaFrame.sendListF("flights").get(i).aircraft_id == Integer.parseInt((String) aircraft_id.getSelectedItem()) && kassaFrame.sendListF("flights").get(i).departurecityid ==Integer.parseInt((String) departure_city.getSelectedItem()) && kassaFrame.sendListF("flights").get(i).arrivalcityid == Integer.parseInt((String)arrival_city.getSelectedItem())){
                        available_flight_ids.add(kassaFrame.sendListF("flights").get(i).id);

                    }
                }
                for(int i =0;i<available_flight_ids.size();i++){
                    for(int j=0;j<kassaFrame.sendListT("tickets").size();j++){
                        if(available_flight_ids.get(i).equals(kassaFrame.sendListT("tickets").get(j).flight_id)){
                            available_tickets_id.add(kassaFrame.sendListT("tickets").get(j).flight_id);
                            z=1;
                        }
                    }
                }
                if(z==0){
                    error.setVisible(true);
                }if(z==1){
                    kassaFrame.getBuyTicket().setVisible(false);
                    kassaFrame.getSearchTicket().setVisible(true);
                }
                for(int i=0;i<available_tickets_id.size();i++){
                    kassaFrame.getSearchTicket().available_tickets.addItem(available_tickets_id.get(i));
                }

            }
        });
    }
}
