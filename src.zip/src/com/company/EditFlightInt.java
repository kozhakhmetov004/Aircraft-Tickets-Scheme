package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EditFlightInt extends JPanel {
    AdminFrame adminFrame;
    JLabel enterl;
    JTextField enter;
    JButton back;
    JButton edit;
    public EditFlightInt(AdminFrame adminFrame) {
        this.adminFrame = adminFrame;
        setSize(520, 500);
        setLayout(null);
        Color blue = new Color(18, 77, 114);
        Color grey = new Color(102, 102, 102);
        setBackground(grey);
        enterl = new JLabel("ENTER INT:");
        enterl.setBounds(100, 100, 300, 30);
        enterl.setForeground(Color.white);
        add(enterl);
        enter = new JTextField();
        enter.setBounds(100, 150, 300, 30);
        add(enter);
        back = new JButton("BACK");
        back.setBounds(275, 400, 100, 30);
        back.setBackground(blue);
        back.setForeground(Color.white);
        add(back);
        edit = new JButton("EDIT");
        edit.setBounds(125, 400, 100, 30);
        edit.setBackground(blue);
        edit.setForeground(Color.white);
        add(edit);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adminFrame.getEditFlightInt().setVisible(false);
                adminFrame.getEditFlightParameter().setVisible(true);
            }
        });
        edit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(adminFrame.getEditFlightParameter().parameter.getText().equals("id")){
                    int id = 0;
                    Flight flight = null;
                    for(int i =0; i<adminFrame.sendListF("flights").size();i++){
                        if(adminFrame.sendListF("flights").get(i).id == Integer.parseInt(adminFrame.getEditFlightParameter().id.getText())){
                            id = Integer.parseInt(enter.getText());
                            flight = adminFrame.sendListF("flights").get(i);
                        }
                    }
                    adminFrame.FlightEditInt("id",flight,id);
                    enter.setText("");
                    adminFrame.getEditFlightParameter().parameter.setText("");
                    adminFrame.getEditFlightParameter().id.setText("");
                }if(adminFrame.getEditFlightParameter().parameter.getText().equals("departure_time")){
                    int departure_time=0;
                    Flight flight = null;
                    for(int i = 0; i<adminFrame.sendListF("flights").size();i++){
                        if(adminFrame.sendListF("flights").get(i).id == Integer.parseInt(adminFrame.getEditFlightParameter().id.getText())){
                            departure_time = Integer.parseInt(enter.getText());
                            flight = adminFrame.sendListF("flights").get(i);
                        }
                    }
                    adminFrame.FlightEditInt("departure_time",flight,departure_time);
                    enter.setText("");
                    adminFrame.getEditFlightParameter().parameter.setText("");
                    adminFrame.getEditFlightParameter().id.setText("");
                }if(adminFrame.getEditFlightParameter().parameter.getText().equals("econom_place_price")){
                    int eco=0;
                    Flight flight = null;
                    for(int i = 0; i<adminFrame.sendListF("flights").size();i++){
                        if(adminFrame.sendListF("flights").get(i).id == Integer.parseInt(adminFrame.getEditFlightParameter().id.getText())){
                            eco = Integer.parseInt(enter.getText());
                            flight = adminFrame.sendListF("flights").get(i);
                        }
                    }
                    adminFrame.FlightEditInt("econom_place_price",flight,eco);
                    enter.setText("");
                    adminFrame.getEditFlightParameter().parameter.setText("");
                    adminFrame.getEditFlightParameter().id.setText("");
                }
                if(adminFrame.getEditFlightParameter().parameter.getText().equals("business_place_price")){
                    int bus=0;
                    Flight flight = null;
                    for(int i = 0; i<adminFrame.sendListF("flights").size();i++){
                        if(adminFrame.sendListF("flights").get(i).id == Integer.parseInt(adminFrame.getEditFlightParameter().id.getText())){
                            bus = Integer.parseInt(enter.getText());
                            flight = adminFrame.sendListF("flights").get(i);
                        }
                    }
                    adminFrame.FlightEditInt("business_place_price",flight,bus);
                    enter.setText("");
                    adminFrame.getEditFlightParameter().parameter.setText("");
                    adminFrame.getEditFlightParameter().id.setText("");
                }
            }
        });
    }
}
